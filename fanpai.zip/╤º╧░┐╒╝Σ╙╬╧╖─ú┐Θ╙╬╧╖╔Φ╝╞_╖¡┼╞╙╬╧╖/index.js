(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [
		{name:"index_atlas_", frames: [[1920,155,64,73],[1979,73,54,71],[1986,146,42,71],[1433,1243,54,71],[1962,571,54,71],[1979,0,54,71],[1963,451,54,71],[1977,305,54,71],[1977,378,52,71],[1921,378,54,71],[1921,305,54,71],[1664,1349,148,89],[0,1508,879,354],[1743,755,116,102],[1635,324,126,126],[1282,1364,126,126],[881,1508,684,324],[1489,755,165,214],[1963,524,81,33],[0,754,1280,752],[1743,859,173,63],[1282,465,532,288],[1635,0,342,153],[1282,0,351,463],[0,0,1280,752],[1861,716,124,69],[1489,1165,143,191],[1634,1156,85,191],[1891,324,28,191],[1656,755,85,192],[1489,971,143,192],[1816,637,144,77],[1721,1156,172,76],[1282,1243,149,119],[1567,1543,111,134],[1731,949,164,77],[1881,517,80,52],[1816,452,63,183],[1567,1358,95,183],[1634,971,95,183],[1962,644,81,25],[1635,155,283,167],[1763,324,126,126],[1282,755,205,486],[1433,1358,126,126],[1920,230,64,73],[1881,571,50,48]]}
];


// symbols:



(lib.第 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._0 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._1 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib._3 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib._4 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib._5 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib._6 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib._7 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib._8 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib._9 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1_1 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7_1 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1_2 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5_1 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.btnbgBmd = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CBitmap14 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CBitmap16 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CBitmap17 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CBitmap18 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CBitmap19 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CBitmap20 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CBitmap21 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CBitmap22 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CBitmap23 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CBitmap24 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.confirmBmd = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.countdown_1 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.countdown_2 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.countdown_3 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.dongshilogo = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.go = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.homeBmd = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.image10 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.replayBmd = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.关 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.star = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.shape40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AiIAdIgLgbQC2BqBYi2IAZA0QgyBhhbAAQg9AAhSgug");
	this.shape.setTransform(42.9,24.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AiAhJIALgbQA3DLC/hDIgTA2QglALgfAAQh5AAgxiug");
	this.shape_1.setTransform(16.3,34.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AiLgsIACgdQB3CuCeh9IAAA4Qg3Aqg1AAQhYAAhTh2g");
	this.shape_2.setTransform(29.6,31.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC9999").s().p("AnRC7IgBgRIgBgbIABguQAIj8CQhsQCMhqEJAdQFGAjAsElQALBFgGBWIgDAlQgHA9gNAzQivA3iqAAQkhAAkSigg");
	this.shape_3.setTransform(-4.2,-7);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// Layer 2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AhqBqQgrgrAAg/QAAg9ArgsQAsgsA+AAQAcAAAYAIIg0B1IByhJQAjApABA4QgBA/grArQgsAsg+AAQg+AAgsgsg");
	this.shape_4.setTransform(13.6,8.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(100,162,62,0.753)").s().p("AirCsQhIhHABhlQgBhkBIhIQBHhGBkAAQAxAAArAQQAsATAkAjIAWAZQAyBAAABTQAABlhIBHQhHBIhlAAQhkAAhHhIgAhohoQgrAsAAA9QAAA/ArArQAsAsA+AAQA+AAAsgsQArgrABg/QgBg4gjgpIhzBJIA1h1QgYgIgcAAQg+AAgsAsg");
	this.shape_5.setTransform(13.4,8.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	// Layer 1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhKHEQl7hBgNlOQgMk2Ckh8QCMhpEJAdQGlAsgxHbQgQCRg3BdQhkCljkAAQhAAAhKgNg");
	this.shape_6.setTransform(-4.2,4.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51,-41.7,108.7,93);


(lib.shape39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC9999").s().p("AhKHEQlyg/gVk/IgBgRIgBgcIABgtQAIj8CQhtQCMhpEJAdQFGAiAsElQALBHgGBUIgDAlQgHA9gNA0QgTBHggA2QhkCljkAAQhAAAhKgNg");
	this.shape.setTransform(-4.2,4.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51,-41.7,93.6,93);


(lib.shape38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AiKgyIAEgdQBqC3CnhyIgFA4Qg0AigxAAQhdAAhOiCg");
	this.shape.setTransform(42.6,37.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgciHIAbgMQhqC2C2BZIg0AYQikhVBxjGg");
	this.shape_1.setTransform(17,50.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AhzhbIAQgYQAPDSDIgeIgcAxQgRACgQAAQiYAAgSjPg");
	this.shape_2.setTransform(31.1,44.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(9.5,29.5,47,35.6);


(lib.shape37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AiIAdIgLgbQC2BqBYi2IAZA0QgyBhhbAAQg9AAhSgug");
	this.shape.setTransform(42.9,24.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AiAhJIALgbQA3DLC/hDIgTA2QglALgfAAQh5AAgxiug");
	this.shape_1.setTransform(16.3,34.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AiLgsIACgdQB3CuCeh9IAAA4Qg3Aqg1AAQhYAAhTh2g");
	this.shape_2.setTransform(29.6,31.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC9999").s().p("AnRC7IgBgRIgBgbIABguQAIj8CQhsQCMhqEJAdQFGAjAsElQALBFgGBWIgDAlQgHA9gNAzQivA3iqAAQkhAAkSigg");
	this.shape_3.setTransform(-4.2,-7);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51,-41.7,108.7,86.8);


(lib.shape36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AhqBqQgrgsAAg+QAAg9ArgtQAsgrA+AAQAcAAAYAJIg0B0IByhJQAjAqABA3QgBA+grAsQgsAsg+AAQg+AAgsgsg");
	this.shape.setTransform(13.6,9.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(100,162,62,0.753)").s().p("AirCsQhIhHABhlQgBhkBIhIQBHhGBkgBQAxABArAQQAsASAkAkIAWAaQAyA/AABTQAABlhIBHQhHBHhlAAQhkAAhHhHgAhohpQgrAtAAA9QAAA+ArAsQAsAsA+AAQA+AAAsgsQArgsABg+QgBg3gjgqIhzBJIA1h0QgYgJgcAAQg+AAgsArg");
	this.shape_1.setTransform(13.4,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhKHEQl7hBgNlOQgMk2Ckh8QCMhpEJAdQGlAsgxHbQgQCRg3BdQhkCljkAAQhAAAhKgNg");
	this.shape_2.setTransform(-4.2,4.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51,-41.7,93.6,93);


(lib.shape35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AiIAdIgLgbQC2BqBYi2IAZA0QgyBhhbAAQg9AAhSgug");
	this.shape.setTransform(42.9,7.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AhkB2QDLg3hDi/IA2ATQA5CwjcA+g");
	this.shape_1.setTransform(12,-1.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AhzBYIgUgVQDQAnAXjIIAnAoQgUCVibAAQgiAAgpgHg");
	this.shape_2.setTransform(27.6,1.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC9999").s().p("AnTDnIABguQAIj8CQhsQCMhqEJAdQFGAjAsEkQALBGgGBWQjlAcjpAAQjpAAjugcg");
	this.shape_3.setTransform(-4.2,-15.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// Layer 2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AhqBqQgrgrAAg/QAAg9ArgsQAsgsA+AAQAcAAAYAIIg0B1IByhJQAjApABA4QgBA/grArQgsAsg+AAQg+AAgsgsg");
	this.shape_4.setTransform(13.6,8.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(100,162,62,0.753)").s().p("AirCsQhIhHABhlQgBhkBIhIQBHhGBkAAQAxAAArAQQAsATAkAjIAWAZQAyBAAABTQAABlhIBHQhHBIhlAAQhkAAhHhIgAhohoQgrAsAAA9QAAA/ArArQAsAsA+AAQA+AAAsgsQArgrABg/QgBg4gjgpIhzBJIA1h1QgYgIgcAAQg+AAgsAsg");
	this.shape_5.setTransform(13.4,8.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	// Layer 1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhKHEQl7hBgNlOQgMk2Ckh8QCMhpEJAdQGlAsgxHbQgQCRg3BdQhkCljkAAQhAAAhKgNg");
	this.shape_6.setTransform(-4.2,4.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51,-41.7,108.7,93);


(lib.shape34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ah5BNIgSgXQDMA3AmjHIAlAsQgeCJiHAAQgrAAg1gOg");
	this.shape.setTransform(41.6,-16.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AhPCHQC3hqhyinIA4AFQBlCbjFB1g");
	this.shape_1.setTransform(9.9,-21.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AhzBkQDSgPgejIIAxAcQAXC3jkAUg");
	this.shape_2.setTransform(25.4,-19.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC9999").s().p("Ak3iKQCMhqEJAdQFGAjAsEkQmsg3nzClQAIj8CQhsg");
	this.shape_3.setTransform(-4.5,-19.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// Layer 2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AhqBqQgrgrAAg/QAAg+ArgrQAsgsA+AAQAcAAAYAJIg0B0IByhJQAjApABA4QgBA/grArQgsAsg+AAQg+AAgsgsg");
	this.shape_4.setTransform(13.6,7.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(100,162,62,0.753)").s().p("AirCsQhIhHABhlQgBhkBIhIQBHhHBkAAQAxAAArARQAsATAkAjIAWAZQAyBAAABTQAABlhIBHQhHBHhlABQhkgBhHhHgAhohoQgrArAAA+QAAA/ArArQAsAsA+AAQA+AAAsgsQArgrABg/QgBg4gjgpIhzBJIA1h0QgYgJgcAAQg+AAgsAsg");
	this.shape_5.setTransform(13.4,7.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	// Layer 1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhKHEQl7hBgNlOQgMk2Ckh8QCMhpEJAdQGlAsgxHbQgQCRg3BdQhkCljkAAQhAAAhKgNg");
	this.shape_6.setTransform(-4.2,4.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51,-41.7,106.6,93);


(lib.shape33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.102)").s().p("AgkGaQl7hAgNlPQgMk2Ckh7QhLB9AIDWQANFOF6BAQD3AsCHhkQhkCkjkAAQhAAAhKgNg");
	this.shape.setTransform(-8,8.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51,-33.4,86,84.7);


(lib.shape32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AhqBqQgrgrAAg/QAAg+ArgsQAsgrA+AAQAcAAAYAIIg0B1IByhJQAjAqABA3QgBA/grArQgsAsg+AAQg+AAgsgsg");
	this.shape.setTransform(13.6,6.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(100,162,62,0.753)").s().p("AirCsQhIhHABhlQgBhkBIhHQBHhIBkABQAxgBArASQAsARAkAlIAWAYQAyBAAABTQAABlhIBHQhHBIhlAAQhkAAhHhIgAhohpQgrAsAAA+QAAA/ArArQAsAsA+AAQA+AAAsgsQArgrABg/QgBg3gjgqIhzBJIA1h1QgYgIgcAAQg+AAgsArg");
	this.shape_1.setTransform(13.4,6.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhKHEQl7hBgNlOQgMk2Ckh8QCMhpEJAdQGlAsgxHbQgQCRg3BdQhkCljkAAQhAAAhKgNg");
	this.shape_2.setTransform(-4.2,4.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AiNgZIgFgdQCVCUCFiZIAKA4Qg5A/hCAAQhMAAhYhVg");
	this.shape_3.setTransform(35.8,-32.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// Layer 2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("Ah5BdQDTAAgQjKIAwAhQAJC3jlADg");
	this.shape_4.setTransform(9.1,-48.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	// Layer 1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("Ah5BNIgSgXQDMA3AmjHIAlAsQgeCJiHAAQgrAAg1gOg");
	this.shape_5.setTransform(25.7,-45.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51,-59.7,101.4,110.9);


(lib.shape30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#176F73").s().p("ADFgkQAqA0ABC5gAgJivQAmBLgaDvgAh9jIIhyE1QA5j0A5hBg");
	this.shape.setTransform(-41.5,-28.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AD5DTQhQkOigDoQhCliitE8QhQkOigDoQFZrzJUOJQhjhgh7A8gAD/C9QgBi5gqg1gAASB/QAbjwgohKgAjgBgIByk1Qg5BBg5D0g");
	this.shape_1.setTransform(-43,-27);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.1,-51.7,94.2,49.4);


(lib.元件7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B36F2B").ss(2,0,1).p("EAgJgXeQhhhhiJAAMg49AAAQiJAAhhBhQhhBhAACJMAAAAnpQAACJBhBhIAEAFQBgBcCGAAMA49AAAQCJAABhhhQBhhhAAiJMAAAgnpQAAhlg1hQQgTgcgZgZg");
	this.shape.setTransform(215.4,160);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A71YHQiCAAhdhcIgpgzQg0hMAAhgMAAAgmWQAAiCBdheQBdhcCCAAMA3rAAAQCAAABbBZIAEADQBdBeAACCMAAAAmWQAACChdBdQhcBciDAAg");
	this.shape_1.setTransform(214.5,160);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#ECCFA4").s().p("A8eZAQiGAAhghcIgEgFQhhhhAAiJMAAAgnpQAAiJBhhhQBhhhCJAAMA49AAAQCJAABhBhQAZAZATAcQA1BQAABlMAAAAnpQAACJhhBhQhhBhiJAAgA/d2qQhdBdAACCMAAAAmWQAABgAzBNIAqAyQBcBdCDAAMA3qAAAQCDAABdhdQBchcAAiDMAAAgmWQAAiChchdIgEgDQhchaiAAAMg3qAAAQiDAAhcBdg");
	this.shape_2.setTransform(215.4,160);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFF9C4").ss(4,0,1).p("EAgJgXTQhhhhiJAAMg49AAAQiJAAhhBhQhhBhAACJMAAAAnTQAACJBhBhIAFAFQBfBcCGAAMA49AAAQCJAABhhhQBhhhAAiJMAAAgnTQAAhlg0hPg");
	this.shape_3.setTransform(217.4,161.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.元件7, new cjs.Rectangle(-1,-1,435.8,323.8), null);


(lib.元件6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#663300").ss(3,1,1).p("EAhJgc8Qg+gVhGAAIg3AAMg8fAAAIgzAAIhcAKQhDAPg6AlQgmAYghAhQhvBvgGCaIgBDcMAAAAgTIAADSIAAHLQAABDATA7IAGATQASAvAeArIACACIArAyQB4B4CoAAMA+JAAAQCoAAB3h4QAhghAYgkIAVglQAphSAAhjIAAgRIAA51IAAnMIAAskQAAidhphzIgOgPQhFhFhWgdg");
	this.shape.setTransform(239.5,187.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#895829").s().p("EglBAXjIBHgHQAZApAlAlIAIAIIhdALQgegrgSgvgEAkAAXkQA0hSAHhlQASAJAOALIAAARQAABjgpBSgEglaAK1IApACIAADPIgpABgEAk8gE3IAAnAIAfgIIAAHLgEglZgY5IAogDIAADcIgpACg");
	this.shape_1.setTransform(239.5,197.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#9D5E1E").s().p("EgjBAYxQglgmgZgoIBNgHIARASQAlAmAqAZIhnALgEAi5AXHQA9hMAPheQAcAKAVAMQgHBlg0BSQgYgRgqgSgEgk2AK+IAiABIAADLIgiACgEAkKgE1IAAjkIAMgHIgMABIAAjGIAtgLIAAG/gEgk2gY1IAigCIAADbIgiACg");
	this.shape_2.setTransform(240,197.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC8111").s().p("EgicAX0IgRgSICygJQGjgLF6BMIATAEIuBAVQgqgagmglgEAiNAW4QhSghh1gpQmziUsigJIgBABIjtAAIAigCQSUgiE3AwQC1AdBmAnQgPBeg9BNgAGdTSIAAABIgZABgEgkPAORIAAgBIAAjMQD2APBPATQBWAVh1AaQhWATjEAWIO5BWQoIgUm9ARgAWYmGQJcgMEciCIAADlgEAkQgLgIAADGQjVAOh+AAQnwAANDjUgEgkPgVWIAAjcQDlgDjSB8QIcA6EmAvQm5gWmcAQg");
	this.shape_3.setTransform(239.5,196.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#AA5E2B").s().p("A/EdMQioAAh4h3IgrgzIgCgCIBdgLIAIAIQBxBmCbAAMA9NAAAQCGAABnhOIAtgnQAighAXgmIAyAjQALAVggARIAVgmIgVAmQgYAkghAhQh3B3ioAAgEglHAYzQgTg6AAhDIAAnLIApgBIAAGKQAABpAvBVIAIAOIhHAHgEAk7AWQIAB5kIAfADIAAZ1QgOgKgSgKgEglaAMZMAAAggTIApgCMAAAAgXgEAk8gXQQAAiNhVhrIgggiQg6g6hEgdQBWAdBFBFIAOAPQBpByAACeIAAMkIgfAJgEgjkgbfQAhghAmgXQA6gmBDgPQg+AVg1ApIgpAkQhyBygDCgIgoADQAGibBvhvg");
	this.shape_4.setTransform(239.5,187.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EBCA47").s().p("A+FcLQhgAAhOgnIgZgOIOBgUIgTgEQl6hNmjAMIiyAIIgJgKQhYhpgBiOIAAlQQG9gQIIAUIu5hWQDEgXBWgSQB1gahWgVQhPgTj2gPMAAAggbQGcgPG5AWQkmgvocg7QDSh7jlADQAFibBuhvQBwhuCcgEMA8eAAAQCfADBvBvQB0ByAACjIAANHQwXEJQXhDIAAAGQkcCBpcANIN4BWIAAYQIgFBCQhmgni1gdQk3gwyUAiIgiABIDtAAIABAAQMiAJGzCUQB1ApBSAhIAyAUIgjAnQhzB0ijAAgAGEV4IAZgBIAAgCg");
	this.shape_5.setTransform(239.5,180.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#C27B12").s().p("A+lctQibAAhxhmIgIgIIBngKIAZANQBOAnBgAAMA8MAAAQCiAABzhzIAjgnQAqARAYARQgXAmgiAhIgtAnQhnBOiGAAgEgkHAZbQgvhVAAhpIAAmKIAigBIAAABIAAFPQAACPBZBpIAJAKIhNAGgEAkFAWkIAFhCIAA4PIAtADIgBZkQgVgMgcgKgEgk2ANFMAAAggYIAigBMAAAAgagEAkKgGYIAMAAIgMAGgEAkKgWlQAAiih0hzQhvhviegDIA3AAQBGAAA+AVQBEAdA6A5IAgAjQBVBrAACNIAAM9IgtALgEgjBgbBIApgkQA1gpA+gUIBcgKIAzAAQicAEhvBuQhvBvgECbIgiACQADigByhzg");
	this.shape_6.setTransform(240,183.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.元件6, new cjs.Rectangle(-1.5,-1.5,482.1,377.7), null);


(lib.元件5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ABgCMQgIgFAJgLIABgBIAOgRIgCABIAMgPIABgBIAEgJIABgGIgBgDQgBgFgPgMIgBAAQgLgIgIgJIgGgGIgJAHQgfAXgsAAQgqAAgfgXIgKgIIgJAEIgCAAIgMADIgOADQgTADgDAEIgBABIgCADQgCAHABAKIADAPIAEAVIAAgBIAAADQACAOgJABQgIAAgGgKQgPgXgBgaQgCgYALgMQALgLAUgEQATgDAUAFIgEgJIgMgCQgQgEgQgLIgNgJQgFgEgDABQgKACgGARIgQAnQgGAMgGgEIgCgBIgBgBIgBgCQgCgEAAgFIAAgBIAAgBIAAAAIAAgLIAAgEIAAAAQABgUAJgRIAAgBIABgBIAAAAIABgBIAAgBQANgXARgEQAPgEAVANQARALARATIAAgBIAAgCIAAAAIAAgBIAAgCIABgBIABgEIAAgBIgBAAIgLgNQgGgJgHgMQgJgQgFgCQgFgCgHACIgDAAIgIAEIgeASIgCABQgMAGgDgIQgDgHAHgKQAQgVAYgKQAXgKAPAGQAOAHAKASQALASABAWIAAABIAEgIIADgEQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAQgDgNADgTQACgPgCgDQgDgFgHgCIgHgBQgRgBgLgCIAAAAIgCAAIgBgBIgFgCIgBgBQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQABgCACgCIAHgEIAAAAQAVgGATAFQATAEAGALQAGALgCAQQgBAOgIANQAfgVAoAAQAsAAAfAXIADABIgBgBQgFgQACgQIADgMIADgHIAEgGIAFgDIASgGIACAAIACAAIABAAQAUABATAKQAIAFAAAGIAKAEQAYAKARAVQAGAKgDAHQgDAIgMgGIgCgBIAAAAIgdgSQgMgGgJABIgCAAIgBABQgFACgJAQIgKAQIgEAGIgBACIgJAKIAAAAIABAFIAAACIAAACIAAAGIABgBQAUgRATgJQAXgKAOAGQARAGAJAZQAKAZgGAfQgCAMgFADQgHAEgFgOIgKgqQgEgQgJgDQgDgCgUALIgRAGIgNADIgGABIACAAIgLABQgDAHgEAGIAEABQAVAFAQANQARAMAEAPQAEAQgNAVQgNAWgYANQgGAEgFAAQgDAAgDgCgABnhpQgEADgBAOQgCATgFANIgBABIACACIAEAFQACgVAKgRQAJgPALgHIgHgBIgCAAIgBAAIgBAAIgCAAQgIAAgEAEg");
	this.shape.setTransform(-0.3,154.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,0,0,0.298)").s().p("AgGLYQgDgDAAgFIAA2gQAAgDADgEQADgCADgBQAEABADACQADAEAAADIAAWgQAAAFgDADQgDACgEAAQgDAAgDgCg");
	this.shape_1.setTransform(-0.6,73.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.元件5, new cjs.Rectangle(-22,0,43.3,168.5), null);


(lib.首页背景 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.Bitmap5_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.首页背景, new cjs.Rectangle(0,0,1280,752), null);


(lib.翻翻乐 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.Bitmap2();
	this.instance.parent = this;
	this.instance.setTransform(-171,-76.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.翻翻乐, new cjs.Rectangle(-171,-76.5,342,153), null);


(lib.魔女_首页 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.Bitmap3();
	this.instance.parent = this;
	this.instance.setTransform(-175.5,-231.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.魔女_首页, new cjs.Rectangle(-175.5,-231.5,351,463), null);


(lib.魔法 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.Bitmap1_2();
	this.instance.parent = this;
	this.instance.setTransform(-266,-144);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.魔法, new cjs.Rectangle(-266,-144,532,288), null);


(lib.StarParticle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// star.png
	this.instance = new lib.star();
	this.instance.parent = this;
	this.instance.setTransform(-25,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.StarParticle, new cjs.Rectangle(-32,-31,64,63), null);


(lib.扑克牌 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{open:0,close:9});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_8 = function() {
		this.stop();
	}
	this.frame_17 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(8).call(this.frame_8).wait(9).call(this.frame_17).wait(1));

	// 图层 3
	this.instance = new lib.CBitmap20();
	this.instance.parent = this;
	this.instance.setTransform(-83,9);

	this.instance_1 = new lib.CBitmap21();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-92,-1);

	this.instance_2 = new lib.CBitmap22();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-69,-49);

	this.instance_3 = new lib.CBitmap23();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-35,-81);

	this.instance_4 = new lib.CBitmap24();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-95,-100);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[]},1).to({state:[{t:this.instance_4}]},6).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance}]},1).to({state:[]},1).wait(1));

	// 图层 1
	this.instance_5 = new lib.CBitmap14();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-71,-83);

	this.instance_6 = new lib.CBitmap16();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-42,-83);

	this.instance_7 = new lib.CBitmap17();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-13,-83);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},1).to({state:[]},1).to({state:[{t:this.instance_7}]},10).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_5}]},1).wait(2));

	// 图层 2
	this.instance_8 = new lib.CBitmap18();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-42,-83);

	this.instance_9 = new lib.CBitmap19();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-71,-83);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},4).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_9}]},4).to({state:[{t:this.instance_8}]},4).to({state:[]},1).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-71,-83,143,191);


(lib.mc_level = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(10));

	// 图层 1
	this.instance = new lib._1();
	this.instance.parent = this;
	this.instance.setTransform(-24,-35);

	this.instance_1 = new lib._2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-29,-37);

	this.instance_2 = new lib._3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-28,-34);

	this.instance_3 = new lib._4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-28,-36);

	this.instance_4 = new lib._5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-28,-34);

	this.instance_5 = new lib._6();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-28,-35);

	this.instance_6 = new lib._7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-25,-32);

	this.instance_7 = new lib._8();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-28,-34);

	this.instance_8 = new lib._9();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-28,-34);

	this.instance_9 = new lib._0();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-7,-35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance,p:{x:-24}}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9},{t:this.instance,p:{x:-43}}]},1).wait(1));

	// 图层 2
	this.instance_10 = new lib.关();
	this.instance_10.parent = this;
	this.instance_10.setTransform(55,-37);

	this.instance_11 = new lib.第();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-119,-37);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11},{t:this.instance_10}]}).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-119,-37,238,73);


(lib.mc_empty = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.mc_empty, null, null);


(lib.LabelTwo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.countdown_2();
	this.instance.parent = this;
	this.instance.setTransform(-47.5,-91.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.LabelTwo, new cjs.Rectangle(-47.5,-91.5,95,183), null);


(lib.LabelThree = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.countdown_3();
	this.instance.parent = this;
	this.instance.setTransform(-47.5,-91.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.LabelThree, new cjs.Rectangle(-47.5,-91.5,95,183), null);


(lib.LabelOne = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.countdown_1();
	this.instance.parent = this;
	this.instance.setTransform(-31.5,-91.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.LabelOne, new cjs.Rectangle(-31.5,-91.5,63,183), null);


(lib.LabelGo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.go();
	this.instance.parent = this;
	this.instance.setTransform(-141.5,-83.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.LabelGo, new cjs.Rectangle(-141.5,-83.5,283,167), null);


(lib.全局背景 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(1,1,1).p("Ehj/g6vMDH/AAAMAAAB1fMjH/AAAg");
	this.shape.setTransform(640,376);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EEEEEE").s().p("Ehj/A6wMAAAh1fMDH/AAAMAAAB1fg");
	this.shape_1.setTransform(640,376);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.全局背景, new cjs.Rectangle(-1,-1,1282,754), null);


(lib.游戏背景 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.Bitmap7_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.游戏背景, new cjs.Rectangle(0,0,1280,752), null);


(lib.帮助面板背景 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.498)").s().dr(-640,-376,1280,752);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.帮助面板背景, new cjs.Rectangle(-640,-376,1280,752), null);


(lib.shape869 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAMBkIgCAAIgBgBIhOgkQgSgNBJAYIAAgBQAYgCgDgVIgNg4IAkgpQAQgVgWgLQhGgSAUgDIBbASQAMACgFANIgBACIg2A/IAQBSIABABIAAAIQgEAMgLAAIgHgBg");
	this.shape.setTransform(6.3,2.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BE5908").ss(1.5,1,1).p("AhICXIgDAAQgJAAgGgFIgCgDQgKgJACgTIAGhEIgGgGIgsgpQgQgPAEgPQACgNAVgJIBJgOIABAAIAehCIAGgIQALgKAJAAIAFAAIANAGQADAEAEAFIACADIABAAIAeA3IADAFIBGAKQASADAHAJIADAGIACAHQAAAKgJAOIgtA4IANBEQABARgGAIIgFAGIgFACQgLAGgSgFIhDgeIgFACIglATIgWALg");
	this.shape_1.setTransform(-0.7,-1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFCC00").s().p("AgEBuIhEgeIgEACQgGgFANgJQBFAjAYAHQgGADgIAAQgHAAgHgDgAgXhTIAAgdIADAGIBGAJQASADAGAJIADAHIACAGQgPgKhXgBg");
	this.shape_2.setTransform(7.2,2.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFFF00","#FCE725"],[0,0.988],4.2,3.8,-10.6,-3.9).s().p("AgVBiQgNAJAGAFIgmAUIgDgFIgFgNIAAgHIAAgBIAHhBIgtgmQgNgKgCgIQABgJAKgGIA9gUIAjhOQAJgOAGAFIABAAIAdA3IgBAdQBYABAQAKQAAAKgJAOIgtA5IANBEQABAQgGAIIgFAGIgFADQgXgHhGgjg");
	this.shape_3.setTransform(2.3,-0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FDA51C").s().p("AgUBsIAAgDIAIg1IgVgMIgsgoQgQgPAEgPQACgOAVgIIBHgOIAQAGIAbg+QAIgVANgHIAMAGIAHAJIADACQgHgFgIAOIgjBPIg9ATQgKAGAAAJQABAIANAKIAtAmIgHBBIgBABIABAHIAEAOIAEAEIgWALIgOAEQgOgSAAgZg");
	this.shape_4.setTransform(-7.3,-0.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F37725").s().p("AgaCXQgIAAgGgFIgDgDQgJgJABgTIAGhEIgFgGIAVALIgIA1IAAADQAAAZAOASgAgLhCIABAAIAehCIAGgIQAKgKAJAAIAHAAQgNAIgIAVIgbA+g");
	this.shape_5.setTransform(-5.6,-1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.4,-17,33.6,32.2);


(lib.元件7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8D4F38").s().p("Eg1MAB5QgzAAglgrQglgrAAg8IAAgBQAAgrATgiQAagRAgAAMBrJAAAQA0AAAkArQAlArAAA9IAAAAQAAAsgTAiQgaAQggAAg");
	this.shape_4.setTransform(68,17.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#703D2A").s().p("EA2oAA+IAAAAQAAg+gkgqQglgrg0AAMhrJAAAQggAAgaARQAIgPAKgMQAlgsA0AAMBrJAAAQA0AAAkAsQAlArAAA8IAAABQAAA9glArQgOARgQAKQASgiAAgsg");
	this.shape_5.setTransform(71.3,14);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.元件7_1, new cjs.Rectangle(-285,0,710.8,29.6), null);


(lib.元件6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.502)").s().p("Ag/KtIAA1ZIB/AAIAAVZg");
	this.shape_7.setTransform(393.9,68.5,1,1.062,0,19.7,0);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.502)").s().p("Ag/KtIAA1ZIB/AAIAAVZg");
	this.shape_8.setTransform(357.6,68.5,1,1.062,0,19.7,0);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.502)").s().p("Ag/KtIAA1ZIB/AAIAAVZg");
	this.shape_9.setTransform(321.3,68.5,1,1.062,0,19.7,0);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.502)").s().p("Ag/KtIAA1ZIB/AAIAAVZg");
	this.shape_10.setTransform(285,68.5,1,1.062,0,19.7,0);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.502)").s().p("Ag/KtIAA1ZIB/AAIAAVZg");
	this.shape_11.setTransform(248.7,68.5,1,1.062,0,19.7,0);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.502)").s().p("Ag/KtIAA1ZIB/AAIAAVZg");
	this.shape_12.setTransform(212.4,68.5,1,1.062,0,19.7,0);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.502)").s().p("Ag/KtIAA1ZIB/AAIAAVZg");
	this.shape_13.setTransform(176.1,68.5,1,1.062,0,19.7,0);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.502)").s().p("Ag/KtIAA1ZIB/AAIAAVZg");
	this.shape_14.setTransform(139.8,68.5,1,1.062,0,19.7,0);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.502)").s().p("Ag/KtIAA1ZIB/AAIAAVZg");
	this.shape_15.setTransform(103.5,68.5,1,1.062,0,19.7,0);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.502)").s().p("Ag/KtIAA1ZIB/AAIAAVZg");
	this.shape_16.setTransform(67.2,68.5,1,1.062,0,19.7,0);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.502)").s().p("Ag/KtIAA1ZIB/AAIAAVZg");
	this.shape_17.setTransform(30.9,68.5,1,1.062,0,19.7,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.元件6_1, new cjs.Rectangle(0,0,424.8,137.1), null);


(lib.主画面腾满副本3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D971B").s().p("AAvCYQgOAAgLgEQgKgDgIgGQgbgVgUhCIgBgEQgNgsAghUQAPgpAIgfIAdAQIAEACIABABIAAAEQgIAbgMAgQgcBOAJAsIABAGQAUBGAdAVIAFADIAAABIgBgBg");
	this.shape.setTransform(-288.4,336.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A4D03B").s().p("AA4CQIAKgLQAFgGACgFQAKgTgBgWQAAgRgGgUIgDgIQgSg4g1glIgSgOQgSgLgngSIgBgBIgEgCIgegPIADgRQACgGAAgFIAkATIABAAIAPAHQAjARASAMIAIADIAHAGIAMAHQA4ApASA8QAIAfgDAXQgCANgGAMQgFAKgMAMIgKAJQgFAGgHAFIgFgDg");
	this.shape_1.setTransform(-277.8,333.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#85B224").s().p("AgoCPIgFgDQgdgWgVhFIgBgHQgJgqAdhPQAMghAIgaIAAgFQAnATARALIATANQA1AmASA5IADAGQAGAUAAARQABAXgKASQgCAGgFAFIgKAMIAFADIgDACIgKAGIgJAEIgMAGIgOAGQgJAFgGABQgXAIgUAAIgMAAg");
	this.shape_2.setTransform(-279.5,337.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#85B224").s().p("AgMDFQgmgEg3g2IgFgFQgfgkgOhXQgGgjgHgcIgCgFQAugEAWACIAYABQBFAIAtAqIAHAGQAPAOAJAPQANAVABAWQAAAGgCAJIgCAPIAGABIgBADIgHALIgFAIIgJAMIgJANIgKANQgUATgSAMIgJAGIgHgBgACFA8QAFgSgBgNQgBgSgKgSQgGgMgLgMIgKgLQgwgvhJgJIAAgOIABgQQAEgUALgVIAHgMIAJgOIABgCIAMAKIAcAYIAKAJIADAEQA/A+AVAkQAIANAFAMQAPAkgJAeQgDAEgEAEIgLAKIgGAEIgMAHIACgIg");
	this.shape_3.setTransform(-353.6,338.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A4D03B").s().p("ABfCvIACgQQACgIAAgHQgBgVgNgVQgJgPgPgPIgHgGQgugqhEgIIgYgCQgWgBguADIgBAAIgFABIgkABIgFgRIgEgLQAQABAbgCIAAAAIASgBQApgDAXABIAKAAIAJAAIAPABQBIAJAxAuQAXAXAJAXQAFAOAAANQABAMgEASIgEANIgGARIgGAAgACzAuQgFgMgIgMQgVgjg/g/IgDgDIgKgKIgcgYIgMgJIgEgDIgTgRIABgBQAJgSAEgNIAWAUIAEADIAKAJIAdAYQBKBIAYAnQANAVAFATQAMAugcAiQAJgegPglg");
	this.shape_4.setTransform(-355.4,330.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6D971B").s().p("AgPDUQglgEg1gzIgDgDQgjghgPhfQgIgsgIghIAjgBIAFgBIACAAIABAFQAIAdAFAiQAPBYAeAjIAFAGQA3A1AlAFIAIAAIgCABQgNAGgMADIgLABIgJgBgACVBNIgTgCQAEgSAAgMQgBgNgEgOQgKgWgXgXQgwgvhJgJIAAgMIAAgFQABgRAHgTIAIgSQAOgWAKgSQAHgKAEgIIASARIAEADIgBABIgJAPIgIAMQgLAUgDAUIgCAQIABAPQBKAIAvAwIALALQAKALAHANQAKARABATQAAAMgEATIgDAHIgFADIgMACIgCAAg");
	this.shape_5.setTransform(-357.4,337.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#6D971B").s().p("AhbCuIgEAAQhOgdgYgjQgGgJgEgMQgDgOAAgQIAAgCIAEAIQAYAjBRAdIAJACQAzANBegeQAogNAggHIAGgBIABACIABAFIARAlQglAIgyAPQhBAVgtAAQgZAAgTgHgAgLh8QgigMgcADQgRABgOAHQgNAFgPAOQgHgKgEgIIgBgCIgEgNIAAgHIAGgGQAPgOAOgGQATgJAXACQARgBARAFQAIACAIADQBIAYAuBGIAPgGIAOgKQATgOAPgVIAIgOIAKgRIABgCIAGACIAbALIgOATQgNAUgPAbQgHAJgHAIQgPAQgRAKIgFADIgNAGQguhGhHgZg");
	this.shape_6.setTransform(464.8,362.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#85B224").s().p("AhHCxIgJgCQhRgdgYgjIgEgIIAAgNQACgYAKgdIAIgRIAJgQIAIgOIAFgKIAHgMIADgDIAEAGIAOgLQAIgFAHgDQAVgKAcACQAUABAXAIIAKAEQBBAZAqBAIAOAYQANAWAUAvIgGABQggAHgoANQhCAVgsAAQgUAAgPgEgAjHA/QgBgHABgHIACgPQADgTAIgYIAIgTIACgEIAGgKIACgDIgDARQgGAkgKAlIgFATIgFAPQgCgHAAgJgAAAh8QgIgDgIgCQgSgFgQABQgXgCgTAJQgOAGgPAOIgHAGIABgQIACgIIAEgQQACgGADgFQAYgZAugDQAOgBARABQAuACBfAhIAFABIAPAGIAmAQIAQAHIgBACIgKARIgIAOQgPAVgTAOIgOAKIgPAGQguhGhIgYg");
	this.shape_7.setTransform(462.7,357.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#A4D03B").s().p("ABfCgIgCgFIgBgBQgUgvgMgWIgOgYQgrhAhBgaIgJgDQgYgJgTgBQgcgCgWAKQgHADgHAGIgPALIgDgHIAOgOIALgLQAQgNAMgGQAPgGAQgCQAcgDAjANQBGAYAvBFIAIAPIAFAJIAGAJQAMAXASArIAIATIAAAAIAUAsIgNACQgKABgKADIgRgmgACShhIgFgCIgQgHIgmgRIgPgFIgFgBQhfghgugDQgRgBgPABQgtADgZAZQAUgtA0gLQAXgFAcACQA0AEBtAmIAmARIAPAGIAFACIAfAMQgKAKgOATIAAABIgbgKg");
	this.shape_8.setTransform(468.6,356.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.主画面腾满副本3, new cjs.Rectangle(-375.8,313.3,864.2,66.9), null);


(lib.shape13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.image10();
	this.instance.parent = this;
	this.instance.setTransform(1.9,163.8,0.8,0.669,-74.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.9,5.8,357.1,245.2);


(lib.shape11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFF591","rgba(255,242,56,0.345)","rgba(255,239,9,0)"],[0,0.365,0.863],-272.9,121.1,-282.8,-159.9).s().p("AvQ3uIehgdMgPEAwXg");
	this.shape.setTransform(98.8,216.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 1
	this.instance = new lib.image10();
	this.instance.parent = this;
	this.instance.setTransform(-9,43.2,1.031,0.718,-5.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9,22.7,244.3,367.9);


(lib.shape9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFF591","rgba(255,242,56,0.345)","rgba(255,239,9,0)"],[0,0.565,1],0,0,0,0,0,293.9).s().p("EgcSAjkQuuruiJytQiIytLuuuQLuuvSuiIQSsiIOuLuQOvLuCIStQCISsruOvQruOuytCJQi4AViwAAQvVAAsep7g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-291,-291,582.2,582.2);


(lib.确定 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.confirmBmd();
	this.instance.parent = this;
	this.instance.setTransform(-38,-23);

	this.instance_1 = new lib.btnbgBmd();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-63.2,-34.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.2,-34.7,124,69);


(lib.btn_replay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.replayBmd();
	this.instance.parent = this;
	this.instance.setTransform(-63,-63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,-63,126,126);


(lib.btn_home = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.homeBmd();
	this.instance.parent = this;
	this.instance.setTransform(-63,-63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,-63,126,126);


(lib.失败重试 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.Bitmap12();
	this.instance.parent = this;
	this.instance.setTransform(-63,-63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,-63,126,126);


(lib.失败返回 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.Bitmap11();
	this.instance.parent = this;
	this.instance.setTransform(-63,-63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,-63,126,126);


(lib.帮助按钮 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.Bitmap10();
	this.instance.parent = this;
	this.instance.setTransform(-58,-51);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({scaleX:1.19,scaleY:1.19,x:-69,y:-61},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58,-51,116,102);


(lib.开始 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.Bitmap1();
	this.instance.parent = this;
	this.instance.setTransform(-68,-36);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({scaleX:1.12,scaleY:1.12,x:-76,y:-40},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68,-36,148,89);


(lib.sprite41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 10
	this.instance = new lib.shape33("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(35));

	// Layer 9
	this.instance_1 = new lib.shape37("synched",0);
	this.instance_1.parent = this;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(27).to({_off:false},0).to({_off:true},1).wait(7));

	// Layer 6
	this.instance_2 = new lib.shape34("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.shape35("synched",0);
	this.instance_3.parent = this;

	this.instance_4 = new lib.shape39("synched",0);
	this.instance_4.parent = this;

	this.instance_5 = new lib.shape40("synched",0);
	this.instance_5.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},25).to({state:[{t:this.instance_3}]},1).to({state:[]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(3));

	// Layer 5
	this.instance_6 = new lib.shape32("synched",0);
	this.instance_6.parent = this;

	this.instance_7 = new lib.shape36("synched",0);
	this.instance_7.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6}]}).to({state:[]},25).to({state:[{t:this.instance_7}]},2).to({state:[]},3).to({state:[{t:this.instance_6}]},2).wait(3));

	// Layer 3
	this.instance_8 = new lib.shape38("synched",0);
	this.instance_8.parent = this;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(28).to({_off:false},0).to({_off:true},2).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51,-59.7,101.4,110.9);


(lib.sprite31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape30("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite31, new cjs.Rectangle(-90.1,-51.7,94.2,49.4), null);


(lib.HomeScene = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var m_world = this;
		
		this.btn_start.addEventListener("mousedown", onBtnStartClick);
		this.btn_help.addEventListener("mousedown", onBtnHelpClick);
		
		function initView()
		{
			//
			m_world.mc_mf.scaleX = m_world.mc_mf.scaleY = 0;
			m_world.mc_mf.alpha = 0;
			createjs.Tween.get(m_world.mc_mf, {loop: false})
						  .to({scaleX:1, scaleY:1, alpha:1}, 500, createjs.Ease.backOut);
			
			//
			m_world.mc_ffl.scaleX = m_world.mc_ffl.scaleY = 0;
			m_world.mc_ffl.alpha = 0;
			createjs.Tween.get(m_world.mc_ffl, {loop: false})
						  .wait(300)
						  .to({scaleX:1, scaleY:1, alpha:1}, 500, createjs.Ease.backOut);
			
			//			  
			m_world.btn_start.scaleX = m_world.btn_start.scaleY = 0;
			m_world.btn_start.alpha = 0;
			createjs.Tween.get(m_world.btn_start, {loop: false})
			              .wait(600)
						  .to({scaleX:1, scaleY:1, alpha:1}, 500, createjs.Ease.backOut)
						  .call(tweenStartBtnSize);
			
			//			  
			m_world.btn_help.scaleX = m_world.btn_help.scaleY = 0;
			m_world.btn_help.alpha = 0;
			createjs.Tween.get(m_world.btn_help, {loop: false})
			              .wait(800)
						  .to({scaleX:1, scaleY:1, alpha:1}, 500, createjs.Ease.backOut)	
			//
			showWitch();
							
			setTimeout(witchFlyAround, 5000);
		}
		
		function tweenStartBtnSize()
		{
			createjs.Tween.get(m_world.btn_start, {loop: true})
						  .to({scaleX:1.1, scaleY:1.1}, 1000, createjs.Ease.quadInOut)
						  .to({scaleX:1, scaleY:1}, 1000, createjs.Ease.quadInOut);
		}
		
		function showWitch()
		{
			m_world.mc_witch.x = 1475;
			
			createjs.Tween.get(m_world.mc_witch, {loop: false})
			              .wait(1000)
						  .to({x: 978}, 500, createjs.Ease.backOut);
							
			createjs.Tween.get(m_world.mc_witch, {loop: true})
						  .to({y:500}, 2000, createjs.Ease.quadInOut)
						  .to({y:465}, 2000, createjs.Ease.quadInOut);
		}
		
		function witchFlyAround()
		{
			var eases = [createjs.Ease.circIn,createjs.Ease.circOut,createjs.Ease.circInOut,
						 createjs.Ease.cubicIn,createjs.Ease.cubicOut,createjs.Ease.cubicInOut,
						 createjs.Ease.linear,
						 createjs.Ease.quadIn,createjs.Ease.quadOut,createjs.Ease.quadInOut,
						 createjs.Ease.quartIn,createjs.Ease.quartOut,createjs.Ease.quartInOut,
						 createjs.Ease.quintIn,createjs.Ease.quintOut,createjs.Ease.quintInOut,
						 createjs.Ease.sineIn,createjs.Ease.sineOut,createjs.Ease.sineInOut]
			
			var leftY = 376 + 250 - Math.random() * 500;
			var rightY = 376 + 250 - Math.random() * 500;
			var ease = eases[Math.floor(Math.random() * eases.length)];
			
			createjs.Tween.removeTweens(m_world.mc_witch);
			
			createjs.Tween.get(m_world.mc_witch, {loop: false})
						  .to({x: -200}, 750, createjs.Ease.backIn)
						  .to({scaleX:-0.35, scaleY:0.35}, 10)
						  .call(function(){m_world.swapChildren(m_world.mc_deep, m_world.mc_witch);})
						  .to({x:-200, y:leftY}, 10)
						  .wait(200)
						  .to({x:1400, y:rightY}, 3000, ease)
						  .to({scaleX:1, scaleY:1, x: 1475, y:465}, 10)
						  .call(function(){m_world.swapChildren(m_world.mc_deep, m_world.mc_witch);})
						  .call(showWitch)
						  .call(function(){setTimeout(witchFlyAround, 6000);});
						  
		}
		
		function onBtnStartClick(e)
		{
			var e = new createjs.Event(GameEvent.SWITCH_SCENE, true);
			e.sceneType = GameGlobalData.SCENE_GAME;
			m_world.dispatchEvent(e, m_world);
		}
		
		function onBtnHelpClick(e)
		{
			var helpPanel = new lib.HelpPanel();
			m_world.addChild(helpPanel);
			
			helpPanel.x = GameGlobalData.STAGE_WIDTH * 0.5;
			helpPanel.y = GameGlobalData.STAGE_HEIGHT * 0.5;
			
			helpPanel.scaleX = 1.5;
			helpPanel.scaleY = 1.5;
			helpPanel.alpha = 0;
			
			var tween = createjs.Tween.get(helpPanel)
									  .to({scaleX:1, scaleY:1, alpha:1}, 750, createjs.Ease.backInOut);
			
			helpPanel.addEventListener("close", onHelpPanelClose, false);
		}
		
		function onHelpPanelClose(e)
		{
			var tween = createjs.Tween.get(e.target)
									  .to({scaleX:1.5, scaleY:1.5, alpha:0}, 750, createjs.Ease.backInOut)
									  .call(function(){
											m_world.removeChild(e.target);
											e.target = null;
									  });
		}
		
		initView();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 2
	this.instance = new lib.dongshilogo();
	this.instance.parent = this;
	this.instance.setTransform(16,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// UI
	this.btn_help = new lib.帮助按钮();
	this.btn_help.parent = this;
	this.btn_help.setTransform(1194,681);
	new cjs.ButtonHelper(this.btn_help, 0, 1, 2);

	this.mc_witch = new lib.魔女_首页();
	this.mc_witch.parent = this;
	this.mc_witch.setTransform(978.5,465);

	this.mc_ffl = new lib.翻翻乐();
	this.mc_ffl.parent = this;
	this.mc_ffl.setTransform(622,411.5);

	this.mc_mf = new lib.魔法();
	this.mc_mf.parent = this;
	this.mc_mf.setTransform(404,238);

	this.btn_start = new lib.开始();
	this.btn_start.parent = this;
	this.btn_start.setTransform(463.7,536);
	new cjs.ButtonHelper(this.btn_start, 0, 1, 2);

	this.mc_deep = new lib.mc_empty();
	this.mc_deep.parent = this;
	this.mc_deep.setTransform(-63.9,413);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mc_deep},{t:this.btn_start},{t:this.mc_mf},{t:this.mc_ffl},{t:this.mc_witch},{t:this.btn_help}]}).wait(1));

	// 背景
	this.instance_1 = new lib.首页背景();
	this.instance_1.parent = this;
	this.instance_1.setTransform(640,376,1,1,0,0,0,640,376);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.HomeScene, new cjs.Rectangle(0,0,1280,752), null);


(lib.Card = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{back:0});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(63));

	// 图层 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Aj0FaIAAmTQgnBEgrA2QgKgegOggQBwiYA6jEIA6ARQggBYgjBNIAAH9gAgrFRIgLg8QA3AGAhgBQAuACAAgxIAAloIA3AAIAAFxQAABfhXgBIgbAAIhAgBgAiODUQA8h1Ash1IA1ASQgvByg5B9QgYgLgdgMgADDgDIAxgWQAxBiA6CEIg1AYQguhxg5h3gADrhEIAthtIknAAQgjBDgkA2IgsgkQBRh0AuiHIA1AVQgUAwgUArIFHAAIAAA7Ig0B7QgdgMgVgHg");
	this.shape.setTransform(-2,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ACOEOQgYgegTgrQhNA5hYArQgSgbgRgRQBkgwBQg+QgdhegJiDIi2AAIAAB0ICPgbIACA3IiRAcIAACmQAABQhMAAQgwACgvgEQgDgfgJgcQA0AHApAAQAhABAAgjIAAiSIiKAbIgOg8ICYgZIAAh+IiYAAIAAg0ICYAAIAAhqIh4APQgFgbgKgdQCtgRB8gaIARA4Qg1AKhFAKIAAByICzAAIgKjQIA7AAQACBwAFBgIEBAAIAAA0Ij+AAQAIBrAVBPQBOhFA4hTIAzAhQhJBjhdBNQAUAyAbAgQAkArAbAAQAPgBAGgXQAKglAKhSQAeANAYAIQgMBPgNArQgQA5g1AAQg8gBg2hIgACPkXIAlgmQA9AvBBA6IgrArQg5g6g/g0g");
	this.shape_1.setTransform(-2,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AkEFZIAAmMQgiA2gmAvIgWg+QBtiTA4i5IA5ATQgiBggoBRIAAHtgAABFGQhlAAAAhlIAAkaIg/APIgJg0IBIgRIAAiQIA3AAIAACEIB1gbIAAi7IA3AAIAACuIC3gqQgFCdgDA6QgDA/gRAUQgTAXgxAAIg3gBQgEgbgHgfQAfAEAeABQAmACABg4QAEg7ABhYIh+AdIAAE3Ig3AAIAAkqIh1AbIAAEcQAAA7A6AAIDDAAQBAAAAJgwQAJgtAHhAQAdAMAdAIQgJBDgLAuQgSBNhkAAg");
	this.shape_2.setTransform(-1.9,-0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgZAuIAAgKIAVAAIAAhEIgVAGIAAgKIAfgJIAABRIAUAAIAAAKg");
	this.shape_3.setTransform(38.1,20.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AiZFZIgIg+QA3AHArABQAvAAgBgzIAAhwIlKAAIAAg0IFKAAIAAgsICKhXIlTAAIAAgzIGpAAIAAA5IinBqIAAATIE0AAIAAA0Ik0AAIAACBQAABahZAAIhogCgAELhbIAAhbIoSAAIAABbIg5AAIAAiOIFCAAQgZglgkgsIAwgfQArAwAdAqIgiAWIEpAAIAACOg");
	this.shape_4.setTransform(-1.4,-0.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgbAuIAAgKIAbgaQAKgKADgGQAEgHAAgGQAAgIgFgEQgEgEgIAAQgLAAgLAKIAAgMQALgIANAAQAMAAAHAHQAHAGAAALQAAAJgEAIQgFAHgMANIgUAUIAAAAIAoAAIAAAKg");
	this.shape_5.setTransform(37.9,20.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgaAqIAAgLQAKAGAMABQAIAAAFgFQAGgFAAgHQgBgRgXAAIgIAAIAAgJIAHAAQAWAAgBgRQAAgOgPAAQgKAAgIAGIAAgKQAJgGAMAAQAKAAAHAGQAIAHAAAJQAAASgTAFQAKABAGAFQAFAGAAAJQABAMgKAIQgIAHgOAAQgMAAgJgFg");
	this.shape_6.setTransform(38,20.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAKAuIAAgYIgpAAIAAgIIAmg7IAOAAIAAA6IALAAIAAAJIgLAAIAAAYgAAGgbIgaAoIAeAAIAAglIAAgJIgEAGg");
	this.shape_7.setTransform(37.8,20.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgZArIAAgMQAJAGAKAAQAJAAAFgFQAGgGAAgIQAAgJgGgFQgGgEgKAAIgOAAIAAgtIAsAAIAAAKIghAAIAAAaIAHgBQAOAAAIAIQAIAGAAANQAAANgJAIQgJAIgOAAQgMAAgHgDg");
	this.shape_8.setTransform(38.1,20.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgUAkQgIgKAAgVQAAgXAKgNQAKgPAQAAQAKAAAFADIAAALQgHgEgHAAQgLAAgHAKQgHALgBAQIABAAQAGgMANAAQAMAAAHAIQAHAHAAAMQAAAOgIAJQgIAIgNAAQgNAAgHgLgAgLAEQgFAEAAAIQAAAJAFAGQAFAHAHAAQAHAAAFgGQAEgFAAgJQAAgKgEgEQgEgFgJAAQgGAAgFAFg");
	this.shape_9.setTransform(38.1,20.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgRAuIAhhQIgsAAIAAgLIA5AAIAAAFIgiBWg");
	this.shape_10.setTransform(38,20.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgUApQgIgHAAgLQAAgRATgHIAAgBQgQgHAAgOQAAgKAIgHQAHgGALAAQALAAAHAGQAHAGAAAKQAAAPgRAHIAAABQAUAGAAARQAAALgIAIQgIAGgOAAQgMAAgHgGgAgQAWQAAAHAEAEQAFAFAHAAQAIAAAFgFQAFgEAAgGQAAgNgSgHQgQAHAAAMgAgJggQgEADAAAGQAAALANAGQAPgGAAgLQAAgHgEgDQgEgEgHAAQgFAAgEAFg");
	this.shape_11.setTransform(38,20.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgXAsIAAgLQAIAFAIAAQALAAAHgKQAGgKAAgRQgFALgNAAQgMAAgHgIQgIgGAAgNQAAgOAIgIQAIgJAMAAQAOAAAIALQAHALAAAUQAAAYgKANQgJAOgRAAQgKAAgGgDgAgLgfQgGAGAAAJQABAIAEAGQAFAEAHAAQAHAAAFgEQAFgFAAgGQAAgLgFgGQgEgGgIAAQgHAAgEAFg");
	this.shape_12.setTransform(38,20.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgWEXIAAlmIAtAAIAAFmgAgOiGIhkiQIA5AAIA5BIIA6hIIA5AAIhlCQg");
	this.shape_13.setTransform(18.8,-2.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("ABpC3IAAjIQAAg/gYgdQgZgdg1AAQggAAgXANQgYANgNAXQgJAPgDASQgDAUAAAtIAACuIgtAAIAAlmIAtAAIAAApQAWgZAbgLQAcgMAjAAQAoAAAeAOQAeAPATAcQAMATAGAaQAFAaAAAyIAAC7g");
	this.shape_14.setTransform(-8.4,6.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AiCDkQg2g4AAhOQAAhOA2g4QA2g4BKAAQBNAAA3A3QA3A3AABMQAABQg1A5Qg2A5hNAAQhNAAg2g4gAhhgJQgnApAAA+QAAA+AoAqQAnAqA6AAQA6AAAngqQAngqAAg/QAAhAgngoQgogpg8AAQg3AAgoArgAgNiLIhliQIA5AAIA5BIIA6hIIA5AAIhlCQg");
	this.shape_15.setTransform(29.2,-4.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("ABUC0IhUkRIhTERIgdAAIh6lmIAxAAIBXELIBTkLIAfAAIBTELIBXkLIAwAAIh4Fmg");
	this.shape_16.setTransform(-21.3,5.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AiBCyQg1g1AAhQQAAhPA1g3QA2g2BQAAQApAAAjAQQAjASAWAgIAAg6IAtAAIAAFmIgtAAIAAg5QgWAggkAQQgmATgpgBQhPAAgzg2gAheg6QgoAqAAA/QAAA9AoAoQAoApA4AAQA3AAApgrQAogqAAg/QAAg5gogqQgpgqg1AAQg5AAgpAqgAhhi+IAAgpIC6AAIAAApg");
	this.shape_17.setTransform(18.4,0.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgeDUQgfgeAAg+IAAjRIhEAAIAAgxIBEAAIAAhiIAyAAIAABiIBrAAIAAAxIhrAAIAADRQAAAmAQAQQANAOAagBQAdAAAGgtIAzAAQgJA4gXAUQgZATgdABQgtAAgdgag");
	this.shape_18.setTransform(-20.6,-0.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAHA5IAAhYIgMAJIgPAIIAAgOQAMgFAIgIQAIgIAEgIIAJAAIAAByg");
	this.shape_19.setTransform(41.5,40.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAIETIAAlmIAuAAIAAFmgAASiKIhHiIIAkAAIBHCIg");
	this.shape_20.setTransform(16.7,-4.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("Ah7C0IAAgsIC7kPIimAAIAAgrIDYAAIAAAxIi2EGIDAAAIAAAvg");
	this.shape_21.setTransform(-4.4,5.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AglA5QAAgEACgFQADgIAGgIQAGgHAMgKQASgPAHgIQAGgJAAgIQAAgIgGgGQgGgGgJAAQgKAAgGAGQgGAGAAALIgOgBQABgRAKgIQAKgJAPAAQAQABAKAIQAKAKAAAOQAAAGgDAHQgDAGgGAHIgWAUIgPAPQgEADgCAEIA3AAIAAANg");
	this.shape_22.setTransform(41.9,40.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgZAxQgKgIgBgOIAOgDQACAMAGAFQAGAGAIAAQAJAAAHgHQAHgHAAgKQAAgKgGgGQgHgGgJAAQgEAAgFACIABgMIACAAQAIAAAIgFQAGgEABgKQgBgIgFgFQgFgFgHAAQgJAAgFAFQgFAFgCALIgOgDQACgOAKgIQAJgHAOgBQAIAAAIAFQAIADAEAIQAEAGAAAJQAAAGgEAHQgEAGgHADQAJADAGAGQAFAHABALQAAAPgLALQgLAKgQAAQgPABgKgKg");
	this.shape_23.setTransform(42.1,40.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAKA5IAAgbIgxAAIAAgNIA0hJIALAAIAABJIAQAAIAAANIgQAAIAAAbgAgZARIAjAAIAAgzg");
	this.shape_24.setTransform(41.8,40.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgaAwQgJgIgCgOIAPgBQABAKAHAFQAFAGAJAAQAJAAAHgIQAHgIAAgMQAAgMgHgGQgGgHgLAAQgGAAgFADQgGADgDAEIgOgCIAMg6IA4AAIAAAOIgtAAIgGAfQAKgIALABQAPgBAKALQAKAJAAARQAAAPgJAMQgLAOgSgBQgPABgLgKg");
	this.shape_25.setTransform(42.1,40.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgaAuQgLgNAAgeQAAghANgOQAKgNARgBQAOAAAJAIQAIAHACAOIgOABQgCgIgDgEQgGgGgIAAQgGAAgFAEQgHAFgEAJQgEAKAAAQQAFgHAIgEQAHgEAHAAQAOAAAKALQAKAJAAARQAAAKgFAJQgEAJgJAGQgIAEgKAAQgRABgLgNgAgOACQgHAGAAAMQAAAGAEAHQADAHAFAEQAGADAFAAQAJAAAGgIQAHgGAAgNQAAgLgHgHQgGgHgKAAQgIAAgHAHg");
	this.shape_26.setTransform(42.1,40.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgUA4QAAgNAGgTQAEgUAKgQQAIgSALgMIg3AAIAAgOIBJAAIAAAMQgKALgMATQgKATgFAUQgFAPAAAQg");
	this.shape_27.setTransform(42.1,40.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgaAwQgLgKAAgPQAAgLAGgIQAGgGAKgDQgJgDgEgGQgEgFAAgJQAAgNAJgIQAJgJAOAAQAPABAJAIQAJAJAAANQAAAIgEAFQgEAGgJADQALAEAFAGQAGAIAAALQAAAOgLAKQgKALgRgBQgQABgKgLgAgQAHQgGAHAAAJQAAAHADAFQACAGAGADQAGADAFAAQAKAAAHgHQAGgGAAgKQAAgKgGgHQgHgGgKAAQgJAAgHAGgAgMgpQgGAGAAAGQAAAJAFAFQAGAFAHAAQAIAAAFgFQAGgFAAgHQAAgJgGgFQgFgFgIAAQgHAAgFAFg");
	this.shape_28.setTransform(42,40.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgYAzQgJgIgBgNIANgBQACAJAFAEQAEAFAIAAQAFAAAFgDQAFgDADgFQAEgFACgJQACgIAAgJIAAgCQgFAHgHADQgHAFgIAAQgOgBgKgJQgKgKAAgRQAAgRALgLQAKgLAPAAQALAAAJAHQAJAFAFAMQAFALAAAVQAAAVgFANQgFANgJAGQgKAIgLgBQgOAAgIgHgAgPgmQgHAHAAANQAAAKAGAIQAHAFAJAAQAKAAAGgFQAGgIAAgMQAAgLgGgIQgHgHgJAAQgIAAgHAIg");
	this.shape_29.setTransform(42.1,40.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_4},{t:this.shape_5}]},1).to({state:[{t:this.shape_4},{t:this.shape_6}]},1).to({state:[{t:this.shape_4},{t:this.shape_7}]},1).to({state:[{t:this.shape_4},{t:this.shape_8}]},1).to({state:[{t:this.shape_4},{t:this.shape_9}]},1).to({state:[{t:this.shape_4},{t:this.shape_10}]},1).to({state:[{t:this.shape_4},{t:this.shape_11}]},1).to({state:[{t:this.shape_4},{t:this.shape_12}]},1).to({state:[]},1).to({state:[{t:this.shape_14},{t:this.shape_13}]},38).to({state:[{t:this.shape_16},{t:this.shape_15}]},1).to({state:[{t:this.shape_18},{t:this.shape_17}]},1).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19}]},1).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_22}]},1).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_23}]},1).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_24}]},1).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_25}]},1).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_26}]},1).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_27}]},1).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_28}]},1).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_29}]},1).wait(1));

	// 图层 1
	this.mc_bg = new lib.扑克牌();
	this.mc_bg.parent = this;
	this.mc_bg.setTransform(0,12.1,1,1,0,0,0,0.5,12.5);

	this.timeline.addTween(cjs.Tween.get(this.mc_bg).wait(63));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-71.5,-83.4,143,191);


(lib.帮助面板背景框 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#16721F").ss(1,1,1).p("AimhDQAkAXA6gDIAhgBIBZgIQBJgCAtAzQAUAUAGAeAimhDIAhAmAiJBkQgphKgPh8IAbAfAiCgbQA6A1BQAHQAtAFAeAfQAMANALAR");
	this.shape.setTransform(233.3,-245.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#256609").s().p("AAZCmQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAgBQgQgDgMgGQgygSgmghIgWgTIgFgHQgfgggLghQgGgQgDgQIgBgJQgDgTADgOQAHgcAHgPQAFgJAKgLIANgLQAGgGgJACIAIgCIgBAAIAQgJQAigaAogEQAOgCAQACQAWABAZAKQBXAfAfBpQAeBggWBmIgCAOIgXABQg6AAg6gPgAhxh9IgBABIgVADIgFAFQgLALgDAIQgLAfAJAnIACALIACAHQANAoAeAjQADAEADACIAUAVQAkAdAqASIAbAKIAPAEQA+AQAugHIAJgCQAWhSgRhFQgQhFgrguQgqgvg1gLIgIgBQgPgCgOABQghADggAQIAFAAQAkAEAfALQASAFAPAKQAQAHAPAMQA5AuAdBQIATA4QgwiBhTgyQgQgKgRgGQgngPgtAAIgJAAg");
	this.shape_1.setTransform(301.7,-105.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#75B219").s().p("AAtCSIgPgEIgcgKQgpgSgkgdIgUgVQgDgCgDgEQgegjgNgoIgCgHIgCgLQgJgnALgfQADgIALgLIAFgFIAVgDIABgBQAAAwALAqQAIATAGAUIANAaQAbAtAsAfQANAKAQAJQAyAaBGAMQgOACgPAAQgjAAgsgLgAAvhpQgPgMgQgHQgQgKgRgFQgfgLgkgEQAigFAeAFQARAEAOAHQBPAjArCBQgdhQg5gug");
	this.shape_2.setTransform(300.9,-104.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B2DE0F").s().p("AgBB+QgPgIgNgKQgtgfgbguIgOgbQgGgTgIgTQgKgpAAgwQAygCArAQQARAHAQAKQBSAxAxCBIgTg4QgsiBhNgiQgQgHgRgEQgegGghAGIgGAAQAggRAhgDQAOAAAQACIAIABQA0AKArAvQAqAvARBEQAQBFgWBTIgIACQhGgNgygag");
	this.shape_3.setTransform(304.3,-105.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#52B726").s().p("AA0EJIAFgVIABgDQAPgdgDgXIgCgJQADgbABgaIA0AvQgWCWg8CnQghhAAriigAgGi5QhMiDgphdIAWgVQAZgcAHggQAaACAWgBIAfAyQA9BeAeBqQgnAFgjAaIgQAIIACAAIgIACQAJgBgHAGIgLALIgCgDg");
	this.shape_4.setTransform(287.7,-99.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ABDCtQgHgIAAgLQAAgMAHgHQAJgJALAAQAMAAAJAJQAHAHABAMQgBALgHAIQgJAJgMAAQgLAAgJgJgABXBSQgJgFgLgjQgMgugQgXQgcgpg0gSQhCgXgHgnQgDgQALgJQALgKATADQA7AIAtA3QA7BDAHBrQADAagHAAIgDgBg");
	this.shape_5.setTransform(286.4,-221.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2C9836").s().p("AE6JKQALguAHgrQAQgIAQgMQAWgUAOgbIgFAVQgqCiAgBAIhHCrgAF6FGQgQgIgWAEQgCgsgFgqIACgBQAOgIARgPIAWATQAmAhAyASQgDAmgGAoIgzgvQgCAagDAaQgHgdgagKgAC2CDQgRAvAuAxQAyAJAugJIAXgFIAWgIQgJAIgMAGIgXAKQgpAPhCAHQg9hQAqgxgAEBBvIACABIAAgBIANAHQgIAHgPAdIgBABQgLAPgLAUQgDgiAigtgACZiyIAPgIQAYgMAbgZQAqBdBLCCIACACQgKALgFAJQgHAPgHAcQgDAPADATQgDAAgFACQgviShliFgAhjlvQgdBSBPBWQBRANBMgMIAYgFQAigGAhgNQgXARggAQIgWAJQhKAZhyAOQhqiNBJhVgAgLlDIAKgWQALgbAWgdIADABIAAgBIAXAKQgNANgcAyIgBADIgMAQQgNAUgMAYQgCgbAMgfgAERkwQADgRgBgQQgDgzhNgcQgqgOgbADQgZAFgjAaQgHgQgQgHQg5gWgzAeQhsh6gphqIAKgDQBYBQCHAgQBbAVBegJQAqBfBLB4IgPAAIghgBgAm+s2QgcBOBMBTQBMAMBGgLIAagEIAMALIgDACIgcAKQhEAXhmALQhliFBGhSgAlEtPIAIAfIgSAhIgBACQgUAZgRAfQgDg1AzhFg");
	this.shape_6.setTransform(253.4,-117.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#63A91B").s().p("AhOFZQhbgVhRhCQhAg0guhHQgkg1gIgzQgGgnAKg9QAIg1AUgiQAZguAxgYQA4gfA7ADQAkABAqAOIgZgBQgXAHgUANQgZAQgRAbIgEAEQgaArgKAsQgDANgCANQgFAuAMAtIAGARIABAEQAPAoAaAmIAJAMQAgApAtAmQBNA8ByAQIAfADQAaADAcAAQBeACCagcIACAEQg6AIiEAqQhXAbhXAAQg8AAg9gNgABhhkIAjAqIAHAZQgVglgVgegAggj1IAAAAQg0gfg2gIQAhg6BMgPQgkAngBAdQCAAnBACxQhMh6hSgyg");
	this.shape_7.setTransform(263.7,-207.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#99CC00").s().p("ABWFNQgcAAgagDIgfgEQhygQhNg8QgtglgggpIgJgNQgaglgPgoIgBgEIgGgSQgMguAFgsQACgOADgNQAKgrAagrIAEgFQARgbAZgPQAUgOAXgGIAZAAQAqAOAwAbQAyAbA+BIQAVAeAVAkIgHgYIAPAUIgVgkQg/ixiBgnQABgdAkgmIAMgCIAmgDQCCAABNA1QBQA5AqCEQAJAfAEBAQAEBIAAA5QgBA7AGAqQAFAiAcAlQiQAbhcAAIgMAAgADfAUQgHAIAAALQAAAMAHAIQAKAIAKAAQAMAAAJgIQAIgIAAgMQAAgLgIgIQgJgIgMAAQgKAAgKAIgAAxkgQgKAJACARQAIAmBCAYQA0ASAcApQAQAWAMAwQALAiAJAGQAKAFgCgfQgIhrg7hDQgug3g6gIIgKgBQgNAAgIAHg");
	this.shape_8.setTransform(270.8,-210);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#22AA73").s().p("AhshPQA6A2BQAHQAtAFAdAeQAFARAAANQg+ADgpAeQhygfAAiAg");
	this.shape_9.setTransform(231.1,-240.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#409B17").s().p("AFVM/IAKgOIABgCQBRAKAEhCQACglATghQAFgJAHgLIAFgBIAIgBQATgFAQAHQAYALAEAgQADAUgNAbQgPAcgVARQgLAJgOAIQgPAHgPAFIgZAEQgOACgOAAQgaAAgZgIgAGjKoIAVgGQgiAfgBAnIgEALQgFg0AXgXgAGTLjIgBAJIABgLgAmVolQhSgig7g+IAjgPIADgCQCLBnBNh1QAyhJBUgsIAVgKIAMADQAMAEAMAFQhGA+gPBfQgHAxAHAyQgSAFgRADIgFABIgZADIgcABQg/gBg/gagAjwtGIAsANQhhASgrBIIgRAPQAqhkBHgSgAlcrWIAPgUIgBAAg");
	this.shape_10.setTransform(239.2,-151.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#73CE17").s().p("AFjM9QAKgXADgsIACgDIAAAAQABgyAzgQQgXAXAFA1IAEgMQAPgwAmgVQAEgDAFgBIADgBQgHAKgFAKQgTAhgCAkQgEA6g+AAIgTgBgAFkJAQgugxARguIAJgKQAcgYAmANQgiAtADAiQALgUALgPIABgBQARgaAQgJIABAAQAJgGAMgDIAGgCQADAPAGASQALAhAfAfIgJAJIgWAIIgXAFQgXAFgYAAQgYAAgZgFgABfCVQhPhWAdhRIAHgKIAJgHIAGgFQAKgIALgFQAngSAyAUQgWAdgMAaIgKAVQgMAfACAbQAMgYAOgUIAMgQIABgCQAfguAcgPQAbgQAcgFIA3AHIgBgCQBFAdAJAoQADAOgFAPQgIAfgjAkIAAgBIgTATQghAMgiAHIgYAEQgkAGgmAAQgpAAgrgHgAj9k3QhMhTAchOIAHgKIAJgHQAhABAggFIAogJIABADIAAABQgzBFADA2QARggAUgZIABgCQAKgPAJgLQAPAuAcApQAUAgAaAaIgaAFQghAFgjAAQgmAAgogGgAn5qJQAsgdA0hNIAEgGIABgBQA4hWBvAYQhHASgqBjIARgPQBPhHBXAAIAXABIABAAIAJADIgVAKQhUAsgyBJQgpA+g6AAQg0AAhBgxg");
	this.shape_11.setTransform(238.9,-152.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#16721F").s().p("AF/LWQAGgVADgVIgTADQgxAJg3gWQASgLAGgLIAAAAQALgWADgrIAAgEQADg7BDgRQAOgDARgCQgCgpgFgpQgiAKhLAQQgmgxgFglQgEgkAcgbIAFgFQAkgfApARQAKADAEAIIAEgBQguiUhpiIQg9ASiKAeQhBhWgIg/QgIhAAwgvIAKgKIAGgFQhxh7gqhtQg7ARh0AZQg/hSgIg9QgIg8AvguIACgBQg1gEg3gUQhggjhRhiQAugDAWgNQArgdAzhKIAEgIQBEhoCNAoIATAFQAZAIAcAOIAWAFQATAGAQAIIALgIQAqgeA9gDIATgBQARAAAVADIAMgTQAPgYAWgQQAkgaA3gHIAngCICDAHQA1ALApAcQBLA0AgBMQAhBNACBPQADBPgEA7QgDA8AMAxQAKAxAoAzQhSAIiMAsQgvAQgvAHQApBgBLB3IAjA5QA9BaAfBpQgQgCgOACQgfhqg8hdIghgyQhLh3gqhfQheAJhbgWQiHgghYhQIgKADQApBqBrB6QAzgeA6AXQAQAGAHAQQAjgaAZgEQAbgEAqAOQBNAcADAzQABAQgDARQgHAggZAcIgWAVQgbAZgYANIgPAHQBlCEAvCTQAFgCADAAIABAJIgGACQgMADgJAGIgBAAQgQAJgRAaQAPgdAIgHIgNgHIAAACIgCgCQgmgNgcAYIgJAKQgqAwA9BQQBCgHApgPIAXgKQAMgGAJgIIAJgJIAFAHQgRAPgOAIIgCABQAFAqACAsQAWgDAQAHQAaAKAHAeIACAJQAEAXgQAdIgBADQgOAcgWATQgQAMgQAIQgHArgLAuIAAEGIBHirQA8inAWiWQAGgnADgmQANAFAQAEIgLBSQgoD1iMElIgXAMgAFxIHQgzAQgBAyIAAAAIgCADQgDAsgKAXIgBACIgKAOQAmAMApgHIAZgEQAPgFAPgHQAOgHALgKQAVgRAPgbQANgcgDgTQgEghgYgKQgQgHgTAEIgIABIgFACIgDABQgFABgEADQgmAVgPAwQABgnAigfgAAjjjQgLAFgKAIIgGAFIgIAHIgHAKQhJBWBpCLQBzgNBKgZIAWgJQAggPAXgRIATgTIAAABQAjgkAIgfQAFgPgDgOQgJgphFgdIABACIg3gHQgcAFgbAQQgcAPgfAvQAcgzANgNIgXgJIAAAAIgDAAQgagLgXAAQgVAAgTAJgAhnuxQgxAZgZAtQgUAjgIA1QgKA9AGAnQAIA0AkA1QAuBGBAA0QBQBDBbAUQCVAhCTgvQCEgqA6gIIgCgEQgcglgFgiQgGgqABg7QAAg5gEhIQgEhBgJgfQgqiEhQg5QhNg1iDAAIgmADIgMACQhMAPghA6QA2AHA0AgIAAgBQBTAzBMB5IAVAkIgPgUIgjgqQg/hIgygbQgwgbgqgOQgqgOgkAAIgLgBQg0AAgzAcgAlbqQIgHAKQhGBRBlCGQBmgMBEgWIAcgLIADgBIgMgMQgagagUggQgcgpgPguQgJALgKAPIASggIgIggIAAgBIgBgDIgoAJQggAFghgBgAnJuoIgBABIgEAGQg0BNgsAdIgDADIgjAOQA7A+BSAiQA/AaA/ABIAcgBIAZgDIAFAAQARgDASgFQgHgyAHgyQAPheBGg/QgMgFgMgDIgMgDIgJgDIgBAAIgXgBQhXAAhPBHQArhHBhgTIgsgMQgYgFgVAAQhOAAgsBDgAFhJCIAAgCIgBALgAmAuLIABAAIgPAVg");
	this.shape_12.setTransform(244.2,-135.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#BDEC02").s().p("AAHAFQhjgIgwghIAwgZIBagIQBIgCAtAzQAUAVAGAdQgXAQgPAYQghg7g/gGg");
	this.shape_13.setTransform(238.6,-244.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#55BF26").s().p("ABvBSQgLgRgMgNQgegfgsgFQhQgHg7g1IgDgCIghglQAkAVA7gCIAggBIgvAZQAwAhBiAIQA/AFAhA7IgLAUQgWgDgRAAg");
	this.shape_14.setTransform(232.8,-244.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1B8745").s().p("AgRBqIgXgFQgbgOgagIQgphKgPh8IAbAgIAhAlIADACQABCABxAgIgLAIQgRgIgRgGgAB/AwQAMANALARIgTABQAAgOgEgRg");
	this.shape_15.setTransform(228.9,-243.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#0A7629").ss(0.5,1,1).p("AASg5QAEAAADABQARAIAOAIQAfAbADA4QABAOgBAQQgDAAgCABQioAogGiIQgBgNACgPQAAgPACgRg");
	this.shape_16.setTransform(-251.2,206.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#16721F").ss(0.8,1,1).p("Ag8B1QABAAACAAQAOgCAMgCQCuglhKjAIhrBGQgeASgNAZQgJAPAAATQgBAmAfAwg");
	this.shape_17.setTransform(-215.1,215.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFD2").ss(1,1,1).p("AAuA9QgMhXhPgi");
	this.shape_18.setTransform(-267.9,125.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#73C91D").s().p("AAfAwQhbgGgIgpQgBgJADgMIBCAcQgRgIgPgMQgUgPgOgVQCKARgDBKIgBAFIglAAg");
	this.shape_19.setTransform(-250.7,204.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#489B33").s().p("AgkgFQgEgKgBgHQAAgJAEgFIACgHQAGASAJANQAJAMALAIIgCAOIAEgOIADgBQAJgHAGgKQAGgPgHgVIgCgEQAPAKAFALQAFAGAAAIQAAAHgDAIQgCAGgHAKIgPAVIgPAOQgcgjgIgVg");
	this.shape_20.setTransform(-216.4,249.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#99CD43").s().p("AAJAgQADgNAAgOQgBgRgGgUIASAJIACADQAHAUgGAPQgFAKgKAIIgDABIABgCgAgOANQgJgMgFgRQAGgIAMgGIAIgDIAGAeQACAQAAARIAAAEQgLgIgJgNg");
	this.shape_21.setTransform(-217,247.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#214924").s().p("AgFA/Qgrg0AAgdIAAgBQgBgNAGgKQAHgLAQgHIANgEIACAAIANAFQAfAOAIAVQACAGAAAGQAAAIgDAIQgDAIgGAIQgGALgJALIgWAVIgCACgAgRg1QgMAHgGAHIgDAGQgDAGAAAJQAAAGAEALQAIAVAcAiIAPgOIAQgVQAGgKACgHQADgHAAgGQAAgJgEgGQgGgLgPgJIgRgIQAFATABASQAAAOgDAMIgBACIgEAPIADgPIAAgDQAAgQgCgSIgHgeIgIADg");
	this.shape_22.setTransform(-216.3,249.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B1EA53").s().p("Ag3AkQAOgXANgQQAVgeATgKQALgGAIACQgaAVgOAWQgIALgFALIgEACIAHgCQASAZA5gnQgJAbgSAKQgNAHgRAAQgXAAgfgMg");
	this.shape_23.setTransform(-245.3,242);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#456028").s().p("AhBArIgDAAIACgGQAOgXANgRQAagiAVgMQASgKAPAFQAFABAFADQAJAGAIAMIABAAIAAADQgGA7giATQgOAIgTAAQgaAAgjgOgAALgqQgTAKgVAeQgNAQgOAXQA3AVAdgQQASgKAJgbIAFgbQgrAjglAGIgHACIAEgCQAfgLAjgZIAQgMQgJgMgLgDIgFgCIgEAAIgEgBQgGAAgJAFg");
	this.shape_24.setTransform(-245.2,241.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#F4F79B").s().p("AgmAcQAmgGAqgjIgFAbQgjAYgUAAQgNAAgHgKgAgcAFQAPgVAZgVIAEAAIAFACQALADAJAMIgQAMQgiAZggALQAFgLAIgMg");
	this.shape_25.setTransform(-243.4,241);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#4A9C27").s().p("AhZgWQgBgNACgPQAAgPACgRIBoAZIAHABIAfAQQAfAbADA4QABAOgBAQIgFABQgmAJgeAAQhlAAgFhpgAg/gMQAIAoBaAFIAmABIAAgFQADhKiKgRQAOAVAVAPQAPAMAQAJIhCgdQgDAMACAKg");
	this.shape_26.setTransform(-251.2,206.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#50BE1F").s().p("Ag+ApQgCgNAGgMQARgvBogsQACBVg8AuQgWARgOADIgEAAQgWAAgFgjg");
	this.shape_27.setTransform(-216.2,215.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#409B17").s().p("AhPCBIAAgDQBJgfgBgyQAAgTgLgWQgEgGgDgHQgMgbgDgfQgCgaACgbIAGgGQAXgWAZgCQAMgCAKAEQAWAFARAWQALAOAFAWQACALACAPQACAqgNAhQgJAUgNATQgJAMgKALQgNAPgQAMQgsAjg0AMgAhYgVQgKgdAHgYIAVgTQgGARgCAQQgEAbAIAaQADAIAFAJIAEAOQgSgYgIgVgAhHAFIABAAIAGAOIgHgSg");
	this.shape_28.setTransform(-285.5,186);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#52B726").s().p("AGQGGIgQhCQgUg3gqg6Qg5hQhig6IgVgNIgggQQhdgviTgyQAOgogJg2QBEA6BgA1QC+BlBTBiQAZAeASAhQgBAmAfAwIADAAQAKAlABApgAmSlhIAmgkQAyAwA8AaQAMAaAQAZQgHgBgIABQgdAEgbAYIgJAKIgXATQgzg+gWhUg");
	this.shape_29.setTransform(-260.1,196.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#73CE17").s().p("AAyDcIgBgEIgBAAQgWgrAVgnQAHgQAMgNQgHAYAKAdQAJAVARAZIgDgOIgDgNQgEgaADgXQADgTAHgQQAGgQAKgMIAEgGQgCAbACAaQADAfAMAbQACAHAEAHQALAWAAATQABAyhJAfQgCghgag1gAgxiMIgcgBIgcgEQg8hBAVg+IAMgOQAWgSAagBIATACQALAAALAFQgMARgKAQQgQAcgDAZQgCAJABAIIACgDQAKgSALgPIAHgKIAAgBQAYgjAVgMQAUgMAUgEIApAFQArARAMAZQADAFABAFQADARgKAVQgJAQgRASIgPAOQg6AWhBAAIgIAAg");
	this.shape_30.setTransform(-301.3,168);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2C9836").s().p("AHlMVQAGgJADgHQAfAFAsgTQggAfgoAAIgMgBgAF+KNQgZiIhDhBQAFA8gTA3QgVA2glATIgIAEQgFgDgFgBQAhgjAKg3QALhHgig8QgMgTgSgTQgEg5gegbIAWAOQBiA6A4BPQArA6ATA4IARBBIACAAIADAeQAEAeAHAVQgQAHgHALQgPgegHgrgAGPImQgfgwACgnQAAgTAJgPQANgZAegSIBshGQBKDBiwAkIgZAFIgEAAgAGGG+QgGANADAMQAFAnAZgEQAPgDAWgRQA8gugBhWQhpAtgSAvgAiqDEQANgTAJgWQAOglgCgqIgBgMIAbAZQAIA3gNAoQCSAyBeAvIgHgBIhpgZQgDARAAAPQhlgqhPgxgAmlhVQgNgfgJgiQBSgTASgKQAZgOAfgfIAIgKQABBSAiBKQg8gagygvIgmAjQAWBVAzA9IgOAMIgJAJQgyg8gdhMgAoik9QgVA+A8BCIAcADIAcACQBGABA+gYQgoAghWASIgcAFIgvAHQhRhrA3hBgAnmkAQADgZAQgdQAKgQAMgQIACAAIARAHQgKAJgVAnIAAABIgHAKQgLAQgKASIgCADQgBgJACgIgAlCliQgggLgVAEQgSADgaATQgHgMgMgFQgOgFgOgCQAGhcAihYQAyh6Brh8IAABjIgMAIIgUAKIACAAIgJADQALgBgHAFQgaAUgJATQgIARgJAhQgGAkASA3QATA0A4AzIAAAyIgCAMQgQgVgjgNg");
	this.shape_31.setTransform(-261.1,172.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#75B219").s().p("AA2CvQhOgSg/g1IgCgDQgMgKgLgLQgsgugRg4QgSg8AQgtQAEgKASgSIAagDIABgBQAAA7AOAyQAJAkAQAeQBICGDHAkQgRADgSAAQgrAAg0gOgAA3h/Qg5gthVgLIgOgBIAOgDQCrgTBNDnQgkhghGg4g");
	this.shape_32.setTransform(-276.8,123.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFD2").s().p("AgLAMIgDgMIADgLIALgEIALAGQAEADAAAGIgDALIgMAFQgHAAgEgEg");
	this.shape_33.setTransform(-263.3,135.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#B2DE0F").s().p("AiAAbQgQgegJgjQgOgyAAg8IAOAAQANAAAMACQC7APBVDzIgYhMQhNjmirATIgOACIgHAAQALgGAKgDQA0gVAzAJQA/ANAzA5QAzA3AUBTQAUBSgbBkIgKACQjHgkhIiHgABSB+IgEAMIAEAMQAEADAIAAIALgEIAEgLQAAgHgFgEIgKgFgABeBdQgMhYhQghQBQAhAMBYg");
	this.shape_34.setTransform(-272.7,122);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#256609").s().p("AAeDIQhFgSg5goIgSgPIgIgGQg4gzgSg0QgTg2AHgkQAIghAJgRQAIgTAagUQAHgFgLABIAJgDIgBAAIATgKIAMgIIAagPQBDgfBOAfQBnAmAnB9QAjBzgaB7IgDARIgYABQhHAAhIgSgAiIiUIgaAEQgSARgEALQgRAsASA9QASA3ArAuQALAMAMAJIADADQA/A1BOASQBKAUA3gIIAKgCQAchkgVhSQgThTgzg3Qg0g5g/gNQgygJg0AVQgKADgLAGIAGAAIAPACQBVALA5AsQBGA5AjBfIAZBMQhWjzi6gPQgNgCgNAAIgOAAg");
	this.shape_35.setTransform(-275.9,122.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#16721F").s().p("AHNM3QgIAAgFgCQAJgLAGgLQAwAFAkgiQgsATgfgGQADgJAAgIQAAgGgCgGQAMACATgDIA4gSIArAAQgzBZhKAAIgRgBgAFfKlQgYiGgogTQgBAcgKAgQgUBAgvAZIgDACIAAgDIgBAAQgIgMgJgGIAIgEQAlgTAVg1QATg4gFg7QBDBBAZCHQAHAsAPAeQgGAJABANQgRghgJgxgAGkLKIgCAAIgNAFQgHgWgEgdIgDgeQgBgpgJglIAZgEQAJAnACAqQADA0AOAfIgOgGgABYK9Qg5gGgvgtIgBAAQgpgjgBhDQAcA1AfAdQASARAdAHQAyANAtgTQAwgZAQg8QAPg4gkg3QgKgPgNgOIAGgCQABgPgBgOQASASAMAUQAiA7gLBHQgKA4ghAiQgPgFgSAKQgWAMgaAiIgJAAgAEwGbQhThii+hmQhgg1hDg6IgbgaIABAMQACArgOAkQgJAWgNAUQBPAwBmAqQgBAQAAAMQhxgshUgxQgPAQgRAPQgxAphPAOQANgagBgRIAAAAQgCgfgYg1IgCgFQgbgyAbguQgyg8gehJQgRgrgKgvIg0AMQgyhCgHgwQgFgvAkglIAJgGQAagXAcgEQAJhfAihbQA3iZB5iBQADgDAEAAIAIAAIAFAFIACAHIAAB1IgZAPIAAhjQhrB7gyB7QgiBXgGBdQAOABAOAFQAMAGAHALQAagTASgDQAVgDAgAKQAjANAQAVIACgMIAAgyIAHAGIASAPIAAAfQgeCRBEB6QBLCGDEBsQDDBpBWBlQATAVAOAXQgJAQAAATQgTghgZgegAllBHQgMANgHAQQgVAnAWArIABAAIABAEQAaA1ACAhIAAADIgCAXQAzgMAtgjQAQgMAOgPQAKgLAJgMQANgTAIgUQANgigCgqQgBgPgDgLQgEgWgLgOQgRgWgWgEQgLgEgMACQgZACgXAVIgGAGIgEAGQgKAMgGAQQgHAQgDATQgDAXAEAaIADANQgGgJgDgJQgHgaADgbQACgQAGgRgAk1jVQgfAfgZANQgSAKhSAUQAJAiANAfQAdBKAyA+IAJgKIAOgMIAXgTIAJgKQAbgXAdgEQAIgBAIABQgRgZgMgaQgihKgBhTIgIALgAoslAIgMAOQg3BBBRBqIAvgGIAcgFQBWgSAoggIAPgOQARgSAJgQQAKgVgDgRQgBgFgDgFQgMgZgrgRIgpgFQgUAEgVAMQgVAMgYAjQAVgnAKgKIgRgHIgCAAQgLgFgLAAIgTgCQgaABgWASgAlQCXIgBAAIAAgEIAIASg");
	this.shape_36.setTransform(-258.9,171.4);

	this.instance = new lib.元件7();
	this.instance.parent = this;
	this.instance.setTransform(-0.6,3.6,1.19,1.19,0,0,0,216.8,160.9);

	this.instance_1 = new lib.元件6();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2.1,11.6,1.19,1.19,0,0,0,239.5,187.3);
	this.instance_1.alpha = 0.551;

	this.instance_2 = new lib.元件6();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-2.1,11.6,1.19,1.19,0,0,0,239.5,187.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.帮助面板背景框, new cjs.Rectangle(-319.1,-256.8,638.3,512.7), null);


(lib.HelpPanel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var m_world = this;
		
		this.btn_confirm.addEventListener("mousedown", onConfirmClick);
		
		this.mc_bg.addEventListener("click", function(e){});
		
		function onConfirmClick(e)
		{
			var e = new createjs.Event("close");
			m_world.dispatchEvent(e, m_world);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ag4ABQAEg2A0gDQA1ADAFA2QgFA1g1ADQg0gDgEg1gAgSABQACAQAQACQASgCABgQQgBgQgSgBQgQABgCAQg");
	this.shape.setTransform(-93,99.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("ACCCkQhagognhMQghBQhkAkQgSAHgKgRQgIgVAQgFQBYgbAahCIhrAAQgOgBAAgUQAAgRAOgCIB1AAIAGg0IhoAAQgOgBgCgTQACgSAOgBIAuAAIgNgUQgHgIgEgHQgKgUAOgKQARgLAOAPQAMANAPAZQAJARgDAHIBJAAIAlg+QAKgMARAHQASAIgGAQIgSAgIgHALIAqAAQASACACAQQgCATgSABIhwAAIgDAmIgCAOICHAAQAOACACARQgCAUgOABIhwAAQAmA8BNAhQARAHgIATQgIAMgMAAQgEAAgGgCg");
	this.shape_1.setTransform(-119.9,88.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AiZCgQgTgLAKgRQAKgOAcgcIAAhaQACgCgFAAIgPAAQgRgCgBgRQABgQARgCIAgAAQAbgBgBAdIAABeQALAjBDAEICaAAQARABABARQgBARgRABIiXAAQg6ACgggcQgNgKgIAKIgGAKIgFAIQgIAMgLAAQgEAAgFgCgABHBqIgegBIgEAAQgXgEACgUQAFgUAXADQAcAGABgQIAAh/Ih3AAQgQgBgBgSQABgTAQgBIB3AAIAAgiQACgOASgBQASABACAOIAAAiIAmAAQAPABAAATQgBASgQABIgkAAIAACJQAEArgrAAIgDgBgAgQAcQgFgKgXgbIgHgJQgLgRANgLQAPgKAOAOQARAUAUAdQAJAPgOAKQgHADgFAAQgIAAgIgHgAhnhXQgVgMgYgVQgLgiAnAEQAUANAVARQAOAMgKAQQgHAJgJAAQgFAAgHgEg");
	this.shape_2.setTransform(-156.2,88);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgBCTQgQgIAEgUQAHgRATADIAJACQAcAFAUAAQANACAAgQIAAjQIjnAAQgQgCAAgVQADgUAPgBIEjAAQASABACAUQgCAVgSACIgSAAIAADaQACAxg4gDIgLABQgfAAgggIgAiIAyIAAhoQADgZAbgCICLAAQAaAAAAAeIAABkQACAdgegBIiMAAIgCAAQgaAAABgbgAhfglIAABGQAAAGAGAAIBmAAQAFAAAAgGIAAhGQAAgGgFAAIhmAAQgGAAAAAGg");
	this.shape_3.setTransform(-191.7,89.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AARCQIAAkTQAAgdAYABIBWAAQAaAAAAAgIAADYQgBA0hGgOQgRgEAAgRQADgTARADQAeAJgBgUIAAi9QAAgLgKAAIgnAAQgKAAAAAKIAAD/QgBASgRABQgTgBgBgSgAgXCEIgFgPIgDgGQhMAjgXgEQgYACACgYIAAj4QAAgjAfABIBfAAQAagBAAAfIAAB7QACAageAAIhVAAIAABNQgBAJALgDQASgEAogRIgEgKQgFgHgBgEQgHgOAPgHQARgGAKAOQAUAiAKApQAEAPgOAJIgGAAQgLAAgGgMgAhxgSIBHAAQAEAAAAgFIAAggIhLAAgAhxh1IAAAbIBLAAIAAgbQAAgGgEAAIhBAAQgGAAAAAGg");
	this.shape_4.setTransform(204.1,38.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AggAuQgEgHAHgEQAbgNAGgSQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBgBgBAAIgCAAQgZAAgBgZQACgaAZgBQAuAFgRAxQgVAkgcAKIgEABQgFAAgDgFg");
	this.shape_5.setTransform(159,50.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AijCUIAAkaQAAgbAWACIA+AAQAgAAgCAcQAAAFgMAYQAmgSAdgcQAkggAYAZQAmAdAzAaQAPALgLAUQgMAOgRgNQAKAegfACIgtAAIAAAUIBQAAQARACABASQgBAUgRABIhQAAIAABjQABAtg8gJQgVgCgEgUQgDgXAUAAQAfAHgEgPIAAhSIhLAAQACA9g6gCQgEAAgHgCIgGgCIAABEQgBASgTABQgSgBgBgSgAh9h0IAACbQAIAFAHAAQAUABgCgbQAAgSgSgVQgKgNAAgJQAAgJADgJQAEgOANgcIAEgLQACgFgGgBIgUAAQgFAAAAAEgAhPg0QgBAIAEAGIAKALIAIALIBSAAIAAgUIgpAAQgegCAIgbQgaALgFgVQgGANgDAKgAgUhOIB/AAQgigTgfgaQgjAegbAPgAhFCWQgOgJAKgRQARgeAPgqQAHgSAUAFQAOAHgDAUQgNAsgWAgQgHALgMAAQgGAAgGgDgAB8CKIgjhLQgGgPAQgJQAPgFAKAPQAQAaATAxQAGARgQAIIgIACQgLAAgGgNg");
	this.shape_6.setTransform(132.7,38.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AhJCYIAAi9QAAgfAbACIBBAAIAAhVQABgNATgBQASADABAMIAABUIBKAAQAXAAAAAZIAACmQAGAyhUgQQgXgDgEgPQgBgRASgDIAVACQAdAEgBgLIAAgXIiVAAIAAA6QgCAOgSABQgSAAgCgOgAggA3ICUAAIAAgYIiUAAgAgggXIAAASICUAAIAAgQQAAgIgGABIiHAAQgHgBAAAGgAiPCiQgRgHAGgUIARgxIAPgyQAHgTASAEQARAHgEAWQgRA8gPAmQgJAPgNAAIgFgBgAh3gFIgXgVIgMgMQgMgNAMgOQAMgNAOAMQARAOATATQAMAOgLAOQgHAGgHAAQgHAAgHgGgABlhJQgQgLALgVIAVgeQAIgKABgDQALgNAQAJQAOALgJARQgHARgTAYQgLAMgLAAQgFAAgEgCgAguhSQgOgQgQgXQgLgRAOgMQARgJANAOQAWAcAGAKQALASgNANQgGAEgFAAQgJAAgJgKgAh0hjIgbgdIgDgDQgKgOAMgNQAOgKAMAMQAEAFAHAHQAMALAFAHQAMAQgMAMQgHAGgGAAQgHAAgGgHg");
	this.shape_7.setTransform(95.9,37.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("ABICTIAAgqIiCAAIAAAnQgBASgTACQgTAAgCgTIAAhpQAAgEgEAAIgNAAQgBBFgKAqQgDARgVgCQgOgCAAgNQAIgqACg0QADgvgCiXQACgPASgCQASADACAQIAABDIAPAAIAAhJQACgOAQgBQARABACAOIAABJIAPAAIAAghQAAgbAcAAIApAAIAJgOIAEgHQASgRARASQAHAHgHANIAyAAQAggCgCAYIAABzQADAggZgDIgQAAIAAAiIAoAAQANABABATQAAATgNACIgnAAIAAAqQgCASgTACQgUgCgBgSgAAUBAIA0AAIAAgiIgYAAQgNASgPAQgAhygFIAgAAQAYAAAAAZIAAAsIAdAAQAPgLARgXIgWAAQgcACACgaIAAgoIhFAAgAgGgPQgBAIAIgBIAVAAQAFgHADgQIAAgDIgkAAgAA/gIIAqAAQAGAAAAgKIAAgQIgsAAQAAAJgEARgABGhGIApAAIAAgSQABgKgJABIghAAgAgHhYIAAASIAmAAIAAgbIgfAAQgHAAAAAJg");
	this.shape_8.setTransform(60.4,38.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AggCdIAAibIh4AAQgPgCAAgSQABgVAQgBIB2AAIAAh1QACgPAUAAQATACACAPIAAAeIB3AAQARABACATQgCAUgQABIh4AAIAAAsICNAAQAPABABAVQgBASgPACIiNAAIAAAJQBHAYAzAeQATAOgLAUQgLAPgVgNQgmgZg8gVIAABmQgCAOgTACQgUgCgCgOg");
	this.shape_9.setTransform(24.2,38);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AhsCWIAAiOIgXAPQgUAJgLgRQgJgTARgMQA0gfAegpIhIAAQgOgCAAgSQAAgRAOgBIBgAAIAIgQQAIgXAOABQAjABgJAYIgEANICSAAQAOABACARQAAASgOACIioAAIgRAVICOAAQAkgDgDAjIAACiQAAAlgoAAQgoAAgMgGQgOgFAAgTQAFgOAPgBIALABIAcADQAGAAAAgIIAAgcIioAAIAAA+QgBAPgSABQgUAAgCgPgAhDAxICoAAIAAgVIioAAgAhDgWIAAANICoAAIAAgUIiiAAg");
	this.shape_10.setTransform(-12,37.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("ABSCRIAAipIgjAAQAABshJA2QgQAOgQgKQgOgNAQgMQBDgzgEh2IAAhBQACgYAQgEQA+gGAtgKQAUgEAHAQQAEASgSAHQgWAIhEAHQgHACgBAIIAAAiIBlAAQAOABABATQgBATgOACIgcAAIAACpQgCARgRABQgSgBgBgRgAiXCSQgPgFAFgRQATg4ABhAIAAiAQACgbAZAAQAVAAA4gKIANgBQAUgDAEAOQAEARgRAIQggAHgtAFQgNABACAHIAAAJIA7AAQAhgCgBAeIAABMQAEAggmgCIg8AAQgDA/gRAfQgHAQgPAAIgFgBgAhlAAIAxAAQAEAAAAgFIAAgxQAAgEgEAAIgxAAg");
	this.shape_11.setTransform(-47.9,38.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AAnCdQgSgHADgRQAFgPAUADQAzAKgGgKIAAhJIhOAAQATAcADASQAEARgOAHQgOAGgKgNQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQgGgUgJgOQgLgTAUgHIgjAAQgPgCgBgSQABgSAPgCICFAAIAAgcQACgTASgBQATAAACASIAAAeIAMAAQARACACASQgCASgRACIgMAAIAABQQAEAngngBIgLAAQgXAAgbgJgAhkCRIAAhHIgWAfIgIAMQgQALgOgKQgLgNALgRIANgSIAfgtIABgDQAIgMAHgFIAAg1QgQAWgQgVQgMgigQgiQgFgPAOgHQARgEAJAOQAPAgAKAeIAAhSQABgRATgBQARABACARIAAEkQgCASgRABQgTgBgBgSgAgzgKQgDgRAPgGQAbgEAYgHQgKgXgJgPQgRARgQgDQgZgLAUgYIAKgHQAWgQANgOIAFgFQAQgUAOAAQARAAACAOIBOAAQAfABgOAoQgzBeh+ARIgEAAQgPAAgEgLgAAThpQARAYALAVQAdgOATgZQAGgHAAgDQgBgEgGAAIhBAAg");
	this.shape_12.setTransform(-83.8,38);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("AAACmQgagHgCgPQACgVAYACIALACQAbAFgBgMIAAjEIgqAAQgcA4gMAOQgRALgOgMQgKgNALgSQAbgpARhBQAHgWARAAQAWADgBASIgEAQQgDAIAAAEICHAAQAlgBgFAdQgFA5gRAOQgKAEgHgEQASAwANA5IABAIQACAWgOAEQgXAHgHgaIgGgYQgQg+gNglQgGgOANgJQANgIAMAKIAFgOIACgKQACgKgHAAIgtAAIAADMQAAAqgjAAQgfgBgLgDgAiCCYIAAh9QgOARgTgKQgPgLALgUQApg3AHhZQAAgdAYABQAVACgCAZQgCAdgJAmIgBAKIAADZQgCAQgTABQgUgBgBgQgAg4B2QgRgHAJgVQAVgrARhLQAFgUAWAEQASAGgDAVQgOBFgYA2QgLAOgOAAIgJgCg");
	this.shape_13.setTransform(-120.1,38);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("AgVCRIAAhCQgqAjg9AdQgVANgOgOQgNgSAUgKQA7gcAqglIheAAQgRgBgBgTQABgRARgBIB8AAIAAgTIhdAAQgZAAAAgZIAAhoQAAgWAZAAIDoAAQAXgCAAAZIAABkQABAcgZAAIhiAAIAAATICBAAQAOABgBATQgCASgOAAIhdAAQApApA+AbQAPAEgHATQgIAUgYgLQhDgfgtgsIAABHQgCAOgRABQgUgBgBgOgAATgsIBOAAQAFAAgCgDIAAgSIhRAAgAhjgvQAAABAAAAQAAABABAAQAAAAABABQAAAAABAAIBMAAIAAgVIhPAAgAAThmIBRAAIAAgRQAAgEgDAAIhOAAgAhjh4IAAASIBPAAIAAgVIhMAAQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAAAABg");
	this.shape_14.setTransform(-156,38.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("AiWCdQgLgSASgLQAigUAWgZQgHgHgSgNIgNgKQgSgPAAgJQACgMAJgSQANggALgiIgfAAQgPgBgBgSQABgTAPgBIApAAQACgEACgTIAFgSQAEgSAVABQASADgBAUIgEAZIgDAKIAfAAQAiAAgEAiQgHBJgeBJIAHAGIAcAcQANAQgNALQgOAOgQgRIgdgYQgbAcggAVQgNAIgJAAQgJAAgGgIgAhSgQIgHAQIgDAIIgGANQACADAJAIQAMAHALALQAWgzAJg4QABgIgKgCIgXAAQgFARgMAigACBCaIhPAAQghACABgeIAAjiQgBgiAcABIBUAAQAegDgDAfIAADnQADAcgZAAIgFAAgABtB2QAJABgCgKIAAjCQAAgIgIAAIgqAAQgJAAAAAIIAADCQgBAKAIgBg");
	this.shape_15.setTransform(-192.5,38);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("Ag4ABQAEg2A0gDQA1ADAFA2QgFA1g1ADQg0gDgEg1gAgSABQACARAQABQASgBABgRQgBgQgSgBQgQABgCAQg");
	this.shape_16.setTransform(195,-1.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("AiZCcQgJgVAYgKQBjgnAQhFIh6AAQgUgCgCgSQADgTAVgBIB8AAIAAgvIhMAAIgFAJIgQAUQgRAMgPgKQgNgLALgRQAfgrANgpQAIgOAUAFQARAGgEARIgJAZIA3AAIAAggQABgSATgCQAUAAABATIAAAhIBnAAQAUACABATQgBAUgTABIhoAAIAAAvIB8AAQAUABABATQgBASgTACIhzAAQAZA4BVAsIAMAHQAbATgbARQgSAEgkgWQhEgsgZgqQgbBBhfAnQgLAFgIAAQgMAAgHgJg");
	this.shape_17.setTransform(168,-12.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AhJCYIAAi9QAAgfAbABIBBAAIAAhTQABgNATgCQASADABANIAABSIBKAAQAXABAAAZIAACnQAGAwhUgPQgXgDgEgPQgBgRASgDIAVABQAdAFgBgMIAAgWIiVAAIAAA5QgCAOgSACQgSAAgCgOgAggA3ICUAAIAAgYIiUAAgAgggXIAAASICUAAIAAgRQAAgGgGgBIiHAAQgHAAAAAGgAiPCiQgRgHAGgUIARgxIAPgxQAHgUASAEQARAIgEAUQgRA9gPAmQgJAPgNAAIgFgBgAh3gFIgXgUIgMgNQgMgNAMgOQAMgNAOALQARAOATAVQAMAOgLANQgHAGgHAAQgHAAgHgGgABlhKQgQgKALgUIAVggQAIgJABgDQALgNAQAJQAOALgJARQgHARgTAYQgLAMgLAAQgFAAgEgDgAguhSQgOgRgQgWQgLgRAOgLQARgKANAOQAWAcAGAKQALASgNANQgGAEgFAAQgJAAgJgKgAh0hiIgbgeIgDgDQgKgOAMgNQAOgJAMAKQAEAHAHAHQAMAKAFAIQAMAPgMANQgHAFgGAAQgHAAgGgGg");
	this.shape_18.setTransform(131.9,-12.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("ABrCfIgHgIIgCgDQhxAHhYAAQgXABgEgOQgEgOARgVIAtg7Ig9AAQgPgBgCgTQACgSAPgBIEQAAQAPABACASQAAATgQABIiqAAQAEAHgIALQgMAOgMATQgMAPgEADICUgEIgIgNIgLgOQgKgSAPgMQARgIAOAPIARAYIAiAvQALASgQANQgGAEgGAAQgKAAgIgKgAhOgUQgYgBAHgcQgNAHgSAHIgGACQgWAJgKgRQgIgVAVgJQBCgVBCg9QARgPAJAAQAIAAARANIAEAEQA6AyA+AeQARAKgJAUQgKARgTgHIgKgGIgXgOQAMAegaABgAhOg7ICmAAQgjgVgwgmQglAgguAbg");
	this.shape_19.setTransform(96.2,-12.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("AgaCJIAHgKQAFgGAFgHQgIACgHgXQgHgWgHgRQgFgOAOgHQAOgFAIAMQAMATAEAXQAagwAFhMIgVAAQgHAAgEgFIAAArQgCAbgZABIgbAAIAABsQAAAagbABQgWAAgHgDQgOgFAAgOQACgQAPACQASACgDgIIAAhdIgjAAQgbACACgaIAAgwQAAgeAaAAIBnAAQALgBAFAIQAEgLALAAIAbAAQABgZAAggQACgRARgDQASABABARQAAAjgBAYIA+AAQASACABASQgBASgSACIhBAAIgBASQAdgLAEAcIAAByQAAALAHAAQAKAJgBhCQABgQARgBQAQABABAQQAABCgIAOQgHAUgdgCIgIAAQgjgBgCgeIAAh5QgMBPgtA6QgKARgJACIgGABQgZAAAJgbgAhrgmIAAAYQACADADABIBFAAQAEAAAAgEIAAgYQAAgEgEAAIhFAAQgFAAAAAEgAiWCSQgQgHAHgQQAPgfAFgpQADgSASABQATAEgCASQgHA0gOAaQgIANgNAAIgHgBgAB9heIgRgRIgJgJQgLgKALgMQALgJANAJQASAMAJANQAHAOgKAKQgGAFgGAAQgFAAgFgGgAiOhaQgOAAgBgSQgCgTAPgBIA9AAQgJgKgCgHQAHgYAYAIQALAGAFAJQAIAMgHAGIAzAAQAOABABARQgBASgOACg");
	this.shape_20.setTransform(59.9,-12.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("Ag6CVIAAjlQABgUAUgBQATABACASIAADnQgCATgTABQgUgBgBgTgAh8CVIAAicQgKAXgVgKQgQgMANgYQAig1AThGQAHgQATAEQAQAHgEARQgHAbgIAZIAADuQgCATgTABQgUgBgBgTgAB3CjQgYAAgPgEQgRgGADgQQAFgRATABQAjAHgEgSIAAjLQAAgEgFAAIhDAAQgRgCgBgTQABgUARgBIBZAAQAcgDgCAjIAADkQAEArgrAAIgGgBgAgMhlQgBgGgJgRIgIgRQgHgRARgIQARgGAIANQANAcAGAPQAFATgRAIIgGABQgLAAgHgNg");
	this.shape_21.setTransform(23.3,-12.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AA/CiIhOAAQhdACAFg5IAAifQABgSAUgCQASACABAUIAABIQA2gUBIgsQARgKALAOQAKAQgNAMQhGAshRAiIAAAfQgIAeBBgDIAxAAQAqABAGgFQAKgFABgYQAFgWASgCQARACAAAWQABBFhKAAIgGAAgAB0gUQgSgHAGgSQABgIAEgMIAFgMQACgHgJAAIjXAAQgIAAAAAHIAAAiQgBASgTAAQgSgCgBgSIAAgqQgDgqAiADIBpAAIgGgNQgEgQASgFQAVgEAHAOIAIAYIBiAAQAmgCgFAjQgEAigKAZQgGAPgOAAIgGgBg");
	this.shape_22.setTransform(-11.8,-12.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AggAuQgEgHAHgEQAbgNAGgSQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBgBgBAAIgCAAQgZAAgBgZQACgaAZgBQAuAFgRAxQgVAkgcAKIgEABQgFAAgDgFg");
	this.shape_23.setTransform(-57,0.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("ABvCYIgwAAQg3ABADguIAAh0QgBgiAdADIBCAAQAEABAAgFIAAg+QAAgEgEAAIhPAAQgQABgGgOQgEAPgPAAIgcAAIAAATIAZAAQASABABAXIAADBQABAZgYgBIhvAAQgYABACgbIAAi+QAAgZAVAAIAZAAIAAgTIggAAQgVgBgCgVQACgUAVgBIB+AAQALABAIALQAEgOASAAIBcAAQAggBgBAgIAABfQABAegfgCIhAAAQgGAAABAEIAABfQgBAPAPgBIArAAQAVAJgDg5QABgRATgDQASACABAQQAGBaguAAQgGAAgHgCgAh4BvQAAAEAFAAIBOAAQAEAAAAgEIAAgOIhXAAgAh4gvIAABrIBXAAIAAgSIgLAAQgcABABgfIAAhBIgLAAQADAvgPAmQgEANgMgDQgKgGAEgOQALgcgDgvIgHAAQgFAAAAAGgAgrgBQAAAGAKgCIAAgyQAAgGgEAAIgGAAgAhShZIALAAIAAgTIgLAAg");
	this.shape_24.setTransform(-83.8,-12.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#333333").s().p("AifBzIAAjnQAAgfAegBIEKAAQASABACASQgCATgSABIhMAAIAAB5QAAAVAQgBIATAAQAOAAAAgZQACgSARgCQASAAABARQAFBJg0gGIgfAAQgzADABgyIAAiFIgnAAIAAAsQAEBohBAmQgPAKgNgNQgLgSAMgNQAygjgFhJIAAgsIgtAAQgIAAgBAKIAADIQABAIAIACID3AAQARABADARQgCASgRACIkGAAIgDAAQgkAAABgig");
	this.shape_25.setTransform(-119.2,-12.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("ABaCiIi0AAQgjADADggIAAhCQgCABgLADQgYAIgEgTQgEgTATgIQBEgYA0gjIAEgDQASgMAIAAQARAAASAPIAMAHQBDAlAhAPQAVAHgHAVQgHASgVgIIgEgBIgKgFIAABEQADAdgcAAIgGAAgAhQBVIAAAlQAAAHAHAAICRAAQAIAAgBgHIAAglQABgIgIABIiRAAIgCAAQgFAAAAAHgAgQALIgIAEQgZARgTAIICLAAQgQgIgfgVIgFgDQgMgHgEAAQgFABgOAJgAiSgKQgGgSAPgIQAmgRAmgXQAQgLALAOQALARgPALQgpAcgmARQgIADgGAAQgLAAgEgNgAB/AAIgogVIgugYQgPgHAHgRQAHgRATAGQAmARAMAHQAIgNADgMQADgNgMAAIjgAAQgFAAAAAGIAAAZQgCAPgRACQgSgCgBgPIAAgjQAAglAjAAIBhAAQgDgDACgHIAAgCQAXgeAaAiQADAFAAADIBdAAQAqgBgBArQgCAigUARQAbAOgKAUQgIALgKAAQgFAAgGgDg");
	this.shape_26.setTransform(-156,-13);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AiSCQIAAjlQAAgeAdAAIBkAAIAAgdQACgTASAAQAUACABASIAAAcIBcAAQAggBgBAhIAADSQABAigmgBQgcABgcgIQgRgHABgRQAGgRARABIAPADQAiAJgDgUIAAiuQAAgHgFAAIhOAAQgBAWgEATIAcAXIAZAVIAJAJQAaAVgBAMQgGAdgYgKQgIgGgRgRQgYgZgWgSQgTAqgzAdQgWAKgLgRQgKgSAVgNQA/gfAGhSIhSAAQgFAAgCAHIAADVQgBATgSABQgTgBgBgTg");
	this.shape_27.setTransform(-191.6,-12.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("ABICTIAAgqIiCAAIAAAnQgBASgTACQgTAAgCgTIAAhpQAAgEgEAAIgNAAQgBBFgKAqQgDARgVgCQgOgCAAgNQAIgqACg0QADgvgCiXQACgPASgCQASADACAQIAABDIAPAAIAAhJQACgOAQgBQARABACAOIAABJIAPAAIAAghQAAgbAcAAIApAAIAJgOIAEgHQASgRARASQAHAHgHANIAyAAQAggCgCAYIAABzQADAggZgDIgQAAIAAAiIAoAAQANABABATQAAATgNACIgnAAIAAAqQgCASgTACQgUgCgBgSgAAUBAIA0AAIAAgiIgYAAQgNASgPAQgAhygFIAgAAQAYAAAAAZIAAAsIAdAAQAPgLARgXIgWAAQgcACACgaIAAgoIhFAAgAgGgPQgBAIAIgBIAVAAQAFgHADgQIAAgDIgkAAgAA/gIIAqAAQAGAAAAgKIAAgQIgsAAQAAAJgEARgABGhGIApAAIAAgSQABgKgJABIghAAgAgHhYIAAASIAmAAIAAgbIgfAAQgHAAAAAJg");
	this.shape_28.setTransform(204.4,-62.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AggCdIAAicIh4AAQgPgBAAgSQABgVAQgBIB2AAIAAh1QACgPAUAAQATABACAQIAAAeIB3AAQARABACATQgCAVgQAAIh4AAIAAAsICNAAQAPABABAVQgBASgPABIiNAAIAAAKQBHAYAzAdQATAPgLAUQgLAPgVgNQgmgZg8gVIAABmQgCAOgTACQgUgCgCgOg");
	this.shape_29.setTransform(168.2,-62.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgVCRIAAhCQgqAjg9AdQgVANgOgOQgNgSAUgKQA7gcAqglIheAAQgRgBgBgTQABgRARgBIB8AAIAAgTIhdAAQgZAAAAgZIAAhoQAAgWAZAAIDoAAQAXgCAAAZIAABkQABAcgZAAIhiAAIAAATICBAAQAOABgBATQgCASgOAAIhdAAQApApA+AbQAPAEgHATQgIAUgYgLQhDgfgtgsIAABHQgCAOgRABQgUgBgBgOgAATgsIBOAAQAFAAgCgDIAAgSIhRAAgAhjgvQAAABAAAAQAAABABAAQAAAAABABQAAAAABAAIBMAAIAAgVIhPAAgAAThmIBRAAIAAgRQAAgEgDAAIhOAAgAhjh4IAAASIBPAAIAAgVIhMAAQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAAAABg");
	this.shape_30.setTransform(132,-62);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AiWCdQgLgSASgLQAigUAWgZQgHgHgSgNIgNgKQgSgPAAgJQACgMAJgSQANggALgiIgfAAQgPgBgBgSQABgTAPgBIApAAQACgEACgTIAFgSQAEgSAVABQASADgBAUIgEAZIgDAKIAfAAQAiAAgEAiQgHBJgeBJIAHAGIAcAcQANAQgNALQgOAOgQgRIgdgYQgbAcggAVQgNAIgJAAQgJAAgGgIgAhSgQIgHAQIgDAIIgGANQACADAJAIQAMAHALALQAWgzAJg4QABgIgKgCIgXAAQgFARgMAigACBCaIhPAAQghACABgeIAAjiQgBgiAcABIBUAAQAegDgDAfIAADnQADAcgZAAIgFAAgABtB2QAJABgCgKIAAjCQAAgIgIAAIgqAAQgJAAAAAIIAADCQgBAKAIgBg");
	this.shape_31.setTransform(95.5,-62.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AggAuQgEgHAHgEQAbgNAGgSQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBgBgBAAIgCAAQgZAAgBgZQACgaAZgBQAuAFgRAxQgVAkgcAKIgEABQgFAAgDgFg");
	this.shape_32.setTransform(51,-50.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#333333").s().p("ABICTIAAgqIiCAAIAAAnQgBASgTACQgTAAgCgTIAAhpQAAgEgEAAIgNAAQgBBFgKAqQgDARgVgCQgOgCAAgNQAIgqACg0QADgvgCiXQACgPASgCQASADACAQIAABDIAPAAIAAhJQACgOAQgBQARABACAOIAABJIAPAAIAAghQAAgbAcAAIApAAIAJgOIAEgHQASgRARASQAHAHgHANIAyAAQAggCgCAYIAABzQADAggZgDIgQAAIAAAiIAoAAQANABABATQAAATgNACIgnAAIAAAqQgCASgTACQgUgCgBgSgAAUBAIA0AAIAAgiIgYAAQgNASgPAQgAhygFIAgAAQAYAAAAAZIAAAsIAdAAQAPgLARgXIgWAAQgcACACgaIAAgoIhFAAgAgGgPQgBAIAIgBIAVAAQAFgHADgQIAAgDIgkAAgAA/gIIAqAAQAGAAAAgKIAAgQIgsAAQAAAJgEARgABGhGIApAAIAAgSQABgKgJABIghAAgAgHhYIAAASIAmAAIAAgbIgfAAQgHAAAAAJg");
	this.shape_33.setTransform(24.4,-62.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AggCdIAAicIh4AAQgPgBAAgSQABgVAQgBIB2AAIAAh1QACgPAUAAQATABACAQIAAAeIB3AAQARABACATQgCAVgPAAIh5AAIAAAsICNAAQAPABABAVQgBASgPABIiNAAIAAAKQBHAYAzAdQATAPgLAUQgLAPgVgNQgmgZg8gVIAABmQgCAOgTACQgUgCgCgOg");
	this.shape_34.setTransform(-11.8,-62.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#333333").s().p("AgUCNIAAiGIgNAAQgTgBgCgRQACgUASgBIAOAAIAAh1QABgQATgBQAPABACAQIAAB1IB+AAQAUABACASQgCATgUABIhDAAQAIBIBHAnQAPAKgKARQgLAQgRgJQhPgngQhqIgUAAIAABmQgCAJATgPQAMgLANALQAKANgKAMQgiAfgRAGQgHACgFAAQgRAAABgagAiUCaQgSgJAEgSQAIgQAUAHQAYAHAOgEQAOAAgBg4IAAgUQABgKgIACIgvAAQgYADAEgaIAGhLQgBgXAaACIAlAAQAHACgBgGIAAgZQABgEgEAAIg7AAQgRgCgCgSQACgSAPgCIBMAAQAcgDgCAeIAAA3QABAjgbgEIgnAAQgEAAAAAFIgCAfQgBAEAEAAIAtAAQAYAAAAAdIAAAiQABBYgdAHQgPAFgRAAQgVAAgXgHgAAZgmQgMgQAMgOQAmgmAagnQALgSARAEQASAHgHASQgUAvg0AwQgIAGgIAAQgHAAgIgFg");
	this.shape_35.setTransform(-47.6,-62.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#333333").s().p("AiVCOIAAjIQAAgdAaABIA8AAIAAgiIhTAAQgPgCgCgRQACgTAPgCIElAAQAPACACATQgCARgPACIhWAAIAAAiIBAAAQAcgBgCAfIAACwQADAlgqgDQgXADgSgJQgRgJADgOQAGgMARACQAnAIgGgTIAAiOQAAgJgHAAIgtAAIgBAcQAZAoAVAqQAKAUgNALQgPAKgKgRQgYgugDgBQgOA1gOAZQgIANgOgGQgQgHAEgOIADgHQAGgKABgHQgNADgKgRIgFgKQgGgOgEgEQgNA2gMAWQgKAMgRgGQgQgJAJgPQAcg1AGhaIgoAAQgHAAAAAGIAAC3QgBARgRABQgSgBgCgRgAgggLQAcAhANAeQAOgyAAgxIg0AAQAAAUgDAQgAgahWIAzAAIAAgiIgzAAg");
	this.shape_36.setTransform(-84.1,-61.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#333333").s().p("AAyCKIAAh8IhZAAQgFBhg6AmQgVAOgRgLQgOgRARgOQA2gtABg+Ig/AAQgRgBgBgTQACgSARgBIBBAAIAAheIg4AAQgSgBgBgSQABgSASgCIEQAAQARACACASQgCASgRABIguAAIAABcIA6AAQAOACABATQgBATgOABIg6AAIAAB8QgBAUgSABQgUgBgCgUgAglgZIBXAAIAAheIhXAAg");
	this.shape_37.setTransform(-119.8,-62);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#333333").s().p("AB1CkQgWgCgGgOQgDgTAUgDIAEAAQANABgCgHIAAg1QgQAqgPgGQgEAAgDgEIAAAlQAAAZgkAAQgYAAgIgGQgVgYAegIIAJAAQAPADgBgKIAAhCQgYA4gLgEQgHAAgFgGIAAAlQAAAZgcgBIhUAAQgkADADgeIAAheQAAgEADgHQgcgGASgXIAGgEQAVgUAIgNIgaAAQgOgBgCgRQACgRAOgBIAPAAIgGgJIgIgOQgGgMAJgHQgOgCgCgSQACgOAPgBQA3gCA+gHQAUgDADARQABASgRAFIgZACIgNACIAAAtIAIAAQAFgHAIgXQAGgOAOADQAPAEgEAOQgEAQgEAHIAKAAQAFgRATAIQAIAGAKASQABAFACABIAAgtQAAgKgHAAIgQAAQgSgBgBgRQAAgUARgBIAkAAQAcgDgDAdIAAAoQAKgHAKAHQAKALAIAOIAAgrQAAgJgIAAIgIAAQgQgBAAgTQABgSAQgBIAcAAQAcgCgDAeIAAEDQADAbgjAAIgKAAgAg3B+IARAAQAEAAAAgEIAAgUIgVAAgAhuB6QAAAEAFAAIAQAAIAAgYIgVAAgAg3BHIAVAAIAAgUQAAgEgEAAIgRAAgAhuAzIAAAUIAVAAIAAgYIgQAAQgDABgCADgAAAAgIAAAgQAHgKAIgVIAHgQQALgUAOALIAAgdQgEADgGAAQgHABgLgSIgHgLQgDAEgJABIgVAAQAmAigEAJQgBASgQgBQAEAGAAAHgABTA+IAFgLQAIgSAGgSQAHgOAMAHIAAgbQgIAFgLgOIgHgKIgMgPgAh/APIAFgCIAEAAIAsAAQgNgBAAgNIAAgaQgVAggTAKgAg0AAQgBAMgMABIA0AAQgFgDgNgOIgHgIIgOgRgAhyh2IAKAQQANASgGAHIAKAAIAAgqg");
	this.shape_38.setTransform(-156.3,-62.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("Ag6CcQgFgQARgIQA4gSASgVIg9AAQgEAAgEgBQAIARgeAOIgLAEQgrAUgYAEQgRADgHgQQgEgRAPgHQAbgKArgTIAGgDQARgJAIAFQAAgYARAAIA2AAQgKgDgbgOQgGgDgBgBQgOgJAIgRQAKgNAQAGIAHAFQAYALAKAHQANAPgRAQIARAAQAJgVAMgyQAEgSARAAQASADgBASQgDAcgOAoIA8AAQAQABABASQgBATgQABIhKAAQgiA0hOAZIgGABQgMAAgEgPgACDCmQgTgMgjgUQgPgHAHgRQALgPARAHQAYAJAgAVQALAMgIAPQgIAKgIAAQgFAAgEgDgAiXAYQASgcASgaIgcAAQgdgBAMgiQAYgxAigwQALgLAQAHQAMAKgHAOQgVAkgWAiIgCAEQABABAAAAQAAAAABAAQABABAAAAQABAAABAAIATAAQACgDAFgGQAJgMAEgFQAIgIANAGQAQALgGAIIADgCQAHgFADAAIA+AAIAAgWIg5AAQgPgCgCgQQAAgTAQgBIA5AAIAAgNQABgPAUAAQASABABAQIAAALIBCAAQARABACARQgCASgPACIhEAAIAAAWIBEAAQAZgCgBAgQAAAOgJAYIgDAHQgIANgRgEQgRgFAGgPQANgagNAAIhyAAQAZAJAUAOQALAIgHAPQgKAMgOgFIgmgTQgVgVAdgNIgcAAQgPgBgDgRIgZAmQgTAYgIAOQgBABAAABQgBAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQAAAAABAAQAAAAABAAQABAAABAAIARgDIAOgCQAgANgZAbQgvAIgcAAQgjAAARgmg");
	this.shape_39.setTransform(-192,-62.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AAECfQhDAAgmgmIgKAIIgaAXQgNALgNgOQgLgRAKgMQAdgaAQgSIAAhGQAAgGgGAAIgTAAQgQgCgBgSQABgSAQgCIAtAAQASACABARIAABgQAKAqBVADICHAAQASABACASQgCATgSABgAAhBgIAAgYIhTAAQgOgCgCgSQACgRAOgBIBTAAIAAgeIhFAAQgSAAgFgJQgDgIAMgVIAdg2IgdAAQgQgBgBgSQABgRAQgBIArAAIAJgTQAKgTASAHQARALgIAUIBfAAQATABABARQgBASgTABIhwAAIgXAyQgDAFAEAAIAhAAIAAgMQACgVASgDQASADABAVIAAAMIA+AAQAOACACARQgCARgOABIg+AAIAAAeIBHAAQAOABABARQgBASgOACIhHAAIAAAYQgBATgSACQgSgCgCgTgAhihWQgXgQgWgSQgNgKAJgPQAKgOAOAHQAcARASASQALALgKAQQgFAHgHAAQgFAAgFgDg");
	this.shape_40.setTransform(203.9,-113.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("ACBCdIhMgYIgYgHQhBAbhkADQgTgCAAgTQACgQAUgBQA3ADAmgKIgYgJIgYgHQgSgEAAgNQAAgLARgPIg+AAQgbgTAbgSIBdAAIALgPIhBAAQgdABABgYIAAgwQAAgZASAAIA+AAIAAgWIhTAAQgMgBgDgSQABgSANgCIEiAAQAOACABASQgBASgOABIhUAAIAAAWIA5AAQAagCgCAcIAAAwQACAXgVgBIh7AAQgEALgGAFICcAAQATACAAASQgCARgSABIgwAAQgPAagRARQAiAJArAPQARAEgGATQgGAOgNAAIgGgBgAgsBAQAAADAIADQAKABASAGIAaAHQANgKAPgVIhTAAQgHAHAAAEgAA7gkIAqAAQAEAAAAgEIAAgQQAAgEgEAAIgqAAgAgUgkIAnAAIAAgYIgnAAgAhmg4IAAAQQAAADAEABIAmAAIAAgYIgmAAIgEAEgAgUhgIAnAAIAAgWIgnAAg");
	this.shape_41.setTransform(168,-112.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AiNCOIAAhDQAAgcAYAAIBQAAIADgPIhyAAQgQgBgBgPQABgQAQAAIEpAAQAOAAABAQQgBAPgOABIiJAAIgCAPIBtAAQAcgCgBAZIAAA3QAAAwg8gUQgTgFAAgQQACgTARACQAWAKgBgMIAAgeIgzAAIAAA3QgBARgTADQgTgCgCgRIAAg4IgmAAIAAA4QgCAQgSABQgSgBgCgRIAAg3IgnAAIAAA6QgBARgTACQgSgBgBgRgAApgOQgKAAAAgMQAAgLAKAAIBGAAQAKAAABALQgBAMgKAAgAgTgjIAAgsIhkAAIAAAbQgBASgUAAQgRgDgBgSIAAggQgCgbAaABIBzAAIAAgLIhbAAQgTgBgBgRQABgQATgBIDkAAQARABABAQQgBARgRABIhhAAIAAALIB3AAQAdAAgDAXIgCAMIgDAaQgCARgTABQgVgDACgRQABgDAAgHIACgLQAAgEgFAAIhiAAIAAAsQgCATgSACQgTgCgBgTgAhpgOQgIAAgCgMQACgJAIAAIBFAAQAKAAABAJQgBAMgKAAgAhjgtQgKAAAAgMQAAgLAKAAIA6AAQALAAAAALQAAAMgLAAgAApgwQgKAAAAgLQAAgMAKAAIBCAAQALAAAAAMQAAALgLAAg");
	this.shape_42.setTransform(132,-112.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#333333").s().p("AAACmQgagHgCgPQACgVAYACIALACQAbAFgBgMIAAjEIgqAAQgcA4gMAOQgRALgOgMQgKgNALgSQAbgpARhBQAHgWARAAQAWADgBASIgEAQQgDAIAAAEICHAAQAlgBgFAdQgFA5gRAOQgKAEgHgEQASAwANA5IABAIQACAWgOAEQgXAHgHgaIgGgYQgQg+gNglQgGgOANgJQANgIAMAKIAFgOIACgKQACgKgHAAIgtAAIAADMQAAAqgjAAQgfgBgLgDgAiCCYIAAh9QgOARgTgKQgPgLALgUQApg3AHhZQAAgdAYABQAVACgCAZQgCAdgJAmIgBAKIAADZQgCAQgTABQgUgBgBgQgAg4B2QgRgHAJgVQAVgrARhLQAFgUAWAEQASAGgDAVQgOBFgYA2QgLAOgOAAIgJgCg");
	this.shape_43.setTransform(95.9,-113.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AgVCTIAAhNIhkAAQggACABgmIAAhvQgCgjAgADIBlAAIAAgmQACgQATgCQATACABAPIAAAnIBoAAQAegBgBAfIAAB1QABAjgfgDIhnAAIAABNQgBARgTACQgTgCgCgRgAhtg6IAABPQgCAKALgBIBPAAIAAhiIhPAAQgJAAAAAKgAAUAeIBSAAQAIAAAAgJIAAhPQAAgKgIAAIhSAAg");
	this.shape_44.setTransform(60.1,-113);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#333333").s().p("ACPCmQgrAEgshDQgjAZgcAKQgWAHgIgRQgDgRAVgKQAkgRAYgWQgMgjgFhGIgeACQgSAAgCgTQAAgTARgCIAegBQgDglAAgdQACgQARgBQATAAACAOIAEBCIBJgDQARAAABATQAAATgRACIhJACQACAfAIAuQAYgfANgXQAIgOARAHQAOAIgGARQgJAbgtA2QATAnARAEQAEAGAAgwQACgPAPgCQARAAABAQQACBagUAAIgDAAgAieCKQgNgOAQgRQAxgqAQglIgYgYIgbgYQgRgRANgQQAMgMAUAOQAUARAOAOQAFgbADguQAAgFgFAAIg+AAQgRgBgCgSQACgUAPgBIBYAAQAZAAgCAZQAAA7gQBBQAOAOAMARQAQAUgKAPQgOAOgRgPIgRgSQgdAvgkAbQgLAKgJAAQgGAAgGgEgAB2hmIgRgVIgIgIQgLgOAJgMQAOgLANALQARAOANATQALARgNAMQgFADgFAAQgKAAgIgKg");
	this.shape_45.setTransform(23.7,-113.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#333333").s().p("AApCaQgZgZAfgNQAEAAAJADQAIADADAAQARADACgaQAAgVgBgFIguAAQgQgCgBgUQABgSAQgBIAnAAQgIgNAAgGQAAgHAQgPQAIgHAAgCIgkAAQgVAAADgWQgUAAgBgQQAAgFAEgKIAEgJIg7AAIgBAhIAZAAQAcAAgBAVQgDCZgUARQgLATgmgJQgLgEABgSQADgQALACQAQACABgIQANgsAAhDQABgFgIAAIgMAAQgRB1gZAjQgLAPgQgFQgMgHADgRIAFgMIAHgQQAhhGABh0IgRAAQgHgBgEgEQgCAFgLAAQgLAAgfgtQgBAAAAgBQgBAAAAAAQgBgBAAAAQAAgBAAAAQgBggAfAKIASASIANAOQAHgDAEAAIAkAAIgCgOQgCgSARgEQAUgCAEARIAEAVIAbAAQAOACACAOQAEgGALgfIADgIQAbgYALAfQAAAIgEAJIA4AAQARABABAUQgBAUgPABIhIAAIgNAZIBCAAQAXACgDAWQABANgkAjQAAAFAIAOIAeAAQAOABABASQgBAUgOACIgYAAQADBCgVAMQgHAJgQABIgKABQgUAAgSgIgAidCgQgQgHAHgTQASgoAMg5QAEgPARABQASADgBAQQgKA/gVArQgIANgMAAIgIgBgAiBABQgXgXgIgOQAAgiAfALQAOANARAZQADAZgTAAQgHAAgIgDg");
	this.shape_46.setTransform(-11.6,-113.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#333333").s().p("AhwCXIAAhpQgKAKgHAEQgUALgLgPQgIgQASgPQAWgTANgPIAAgPQABgcAaAHQARgTALgXIhMAAQgSgBgCgUQACgUASgBIBdAAIAFgOQAJgVALgCQAXgCADATQAAAJgGALICOAAQASABAAAWQgCASgTABIiZAAQgYAxglAqIAACVQgBAOgTAAQgSgCgBgOgAgnCZQgUgCAAgTQADgQAUgBIBCAAIAAhZIg9AAQgRgBAAgUQACgRASgCIA6AAIAAgrQACgRATgCQAUADABARIAAAqIA9AAQAUACABARQgBAUgTABIg+AAIAABZIBKAAQAQABACARQgCASgQACg");
	this.shape_47.setTransform(-47.9,-113.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#333333").s().p("Ag4ABQAEg2A0gDQA1ADAFA2QgFA1g1ADQg0gDgEg1gAgSABQACARAQABQASgBABgRQgBgQgSgBQgQABgCAQg");
	this.shape_48.setTransform(-93,-102.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#333333").s().p("ACPCmQgrAEgshDQgjAZgcAKQgWAHgIgRQgDgRAVgKQAkgRAYgWQgMgjgFhGIgeACQgSAAgCgTQAAgTARgCIAegBQgDglAAgdQACgQARgBQATAAACAOIAEBCIBJgDQARAAABATQAAATgRACIhJACQACAfAIAuQAYgfANgXQAIgOARAHQAOAIgGARQgJAbgtA2QATAnARAEQAEAGAAgwQACgPAPgCQARAAABAQQACBagUAAIgDAAgAieCKQgNgOAQgRQAxgqAQglIgYgYIgbgYQgRgRANgQQAMgMAUAOQAUARAOAOQAFgbADguQAAgFgFAAIg+AAQgRgBgCgSQACgUAPgBIBYAAQAZAAgCAZQAAA7gQBBQAOAOAMARQAQAUgKAPQgOAOgRgPIgRgSQgdAvgkAbQgLAKgJAAQgGAAgGgEgAB2hmIgRgVIgIgIQgLgOAJgMQAOgLANALQARAOANATQALARgNAMQgFADgFAAQgKAAgIgKg");
	this.shape_49.setTransform(-120.3,-113.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#333333").s().p("AApCaQgZgZAfgNQAEAAAJADQAIADADAAQARADACgaQAAgVgBgFIguAAQgQgCgBgUQABgSAQgBIAnAAQgIgNAAgGQAAgHAQgPQAIgHAAgCIgkAAQgVAAADgWQgUAAgBgQQAAgFAEgKIAEgJIg7AAIgBAhIAZAAQAcAAgBAVQgDCZgUARQgLATgmgJQgLgEABgSQADgQALACQAQACABgIQANgsAAhDQABgFgIAAIgMAAQgRB1gZAjQgLAPgQgFQgMgHADgRIAFgMIAHgQQAhhGABh0IgRAAQgHgBgEgEQgCAFgLAAQgLAAgfgtQgBAAAAgBQgBAAAAAAQgBgBAAAAQAAgBAAAAQgBggAfAKIASASIANAOQAHgDAEAAIAkAAIgCgOQgCgSARgEQAUgCAEARIAEAVIAbAAQAOACACAOQAEgGALgfIADgIQAbgYALAfQAAAIgEAJIA4AAQARABABAUQgBAUgPABIhIAAIgNAZIBCAAQAXACgDAWQABANgkAjQAAAFAIAOIAeAAQAOABABASQgBAUgOACIgYAAQADBCgVAMQgHAJgQABIgKABQgUAAgSgIgAidCgQgQgHAHgTQASgoAMg5QAEgPARABQASADgBAQQgKA/gVArQgIANgMAAIgIgBgAiBABQgXgXgIgOQAAgiAfALQAOANARAZQADAZgTAAQgHAAgIgDg");
	this.shape_50.setTransform(-155.6,-113.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#333333").s().p("Ah4CUIAAkoQABgQARgCQAUAAACAPIAAErQgCASgSABQgTgBgBgSgAASCcQgmAAgWgJQgegQgBgdQgFghBEhNQAxg3AZgjQAFgFAAgBQAAgDgFAAIhsAAQgRgBgDgTQABgUASgBICiAAQARAAADALQAFALgMAPIgIAJIg0A9IgeAjIg3BCQgUAbAIAQQAHAPAiAAIAoAAQBDABAAgdQABgGAAgMIACgRQABgSAUgCQASACABASQAAAdgEATQgIArgpAGQgVAEgXAAgAijgJQAAgkACgnQABgPASAAQAQADABAPIgCBBIAAAKQgDAWgRgBQgPgDgBgVgAg+glQgJgYgGgZQgCgOAPgGQAQgCAFAOIAIAXIAHAWQAFARgQAGIgGABQgMAAgFgMg");
	this.shape_51.setTransform(-191.8,-113);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#333333").s().p("ABMCiIgtAAQg6AAABglIAAh9QgBgiAfABIBiAAQAJAAAAgIIAAg8QACgHgJAAIh/AAQgRgCgBgSQABgSARgCICOAAQAjgBgCAfIAABeQACAhgfgCIhpAAQgGAAgBAGIAABeQAAAQARAAIBBAAQAmAEgGg0QAAgXAUgBQASABABAXQABAkgGAQQgFAjhDAAIgLAAgAiDB/IAEiXQAAgJgGACIgNAAQgQgCgBgTQABgTAQgBIAjAAQAaABgBAeIgECGQAAAEACgEQALgNAHgOQAMgMAPAJQAMAKgJARQgQAjgbAYQgPAKgKAAQgTAAgEgggAhZhVQgcgVgVgVQgMgPANgOQANgKASAKQAWAOAaAcQALAPgNAOQgHAGgHAAQgHAAgIgGg");
	this.shape_52.setTransform(208.4,-163.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#333333").s().p("ABICTIAAgqIiCAAIAAAnQgBASgTACQgTAAgCgTIAAhpQAAgEgEAAIgNAAQgBBFgKAqQgDARgVgCQgOgCAAgNQAIgqACg0QADgvgCiXQACgPASgCQASADACAQIAABDIAPAAIAAhJQACgOAQgBQARABACAOIAABJIAPAAIAAghQAAgbAcAAIApAAIAJgOIAEgHQASgRARASQAHAHgHANIAyAAQAggCgCAYIAABzQADAggZgDIgQAAIAAAiIAoAAQANABABATQAAATgNACIgnAAIAAAqQgCASgTACQgUgCgBgSgAAUBAIA0AAIAAgiIgYAAQgNASgPAQgAhygFIAgAAQAYAAAAAZIAAAsIAdAAQAPgLARgXIgWAAQgcACACgaIAAgoIhFAAgAgGgPQgBAIAIgBIAVAAQAFgHADgQIAAgDIgkAAgAA/gIIAqAAQAGAAAAgKIAAgQIgsAAQAAAJgEARgABGhGIApAAIAAgSQABgKgJABIghAAgAgHhYIAAASIAmAAIAAgbIgfAAQgHAAAAAJg");
	this.shape_53.setTransform(172.8,-163.2);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#333333").s().p("AB1CkQgWgCgGgOQgDgTAUgDIAEAAQANABgCgHIAAg1QgQAqgPgGQgEAAgDgEIAAAlQAAAZgkAAQgYAAgIgGQgUgYAdgIIAJAAQAPADgBgKIAAhCQgYA4gLgEQgHAAgFgGIAAAlQAAAZgcgBIhUAAQgkADADgeIAAheQAAgEADgHQgcgGASgXIAGgEQAVgUAIgNIgaAAQgOgBgCgRQACgRAOgBIAPAAIgGgJIgIgOQgGgMAJgHQgOgCgCgSQACgOAPgBQA3gCA+gHQAUgDADARQABASgRAFIgZACIgNACIAAAtIAIAAQAFgHAIgXQAGgOAOADQAOAEgDAOQgEAQgEAHIAKAAQAFgRATAIQAIAGAKASQABAFACABIAAgtQAAgKgHAAIgQAAQgSgBgBgRQAAgUARgBIAkAAQAcgDgDAdIAAAoQAKgHAKAHQAKALAIAOIAAgrQAAgJgIAAIgIAAQgQgBAAgTQABgSAQgBIAcAAQAcgCgDAeIAAEDQADAbgjAAIgKAAgAg3B+IARAAQAEAAAAgEIAAgUIgVAAgAhuB6QAAAEAFAAIAQAAIAAgYIgVAAgAg3BHIAVAAIAAgUQAAgEgEAAIgRAAgAhuAzIAAAUIAVAAIAAgYIgQAAQgDABgCADgAAAAgIAAAgQAHgKAIgVIAHgQQALgUAOALIAAgdQgEADgGAAQgHABgLgSIgHgLQgDAEgJABIgVAAQAmAigEAJQgBASgQgBQAEAGAAAHgABTA+IAFgLQAIgSAGgSQAHgOAMAHIAAgbQgIAFgLgOIgHgKIgMgPgAh/APIAFgCIAEAAIAsAAQgNgBAAgNIAAgaQgVAggTAKgAg0AAQgBAMgMABIA0AAQgFgDgNgOIgHgIIgOgRgAhyh2IAKAQQANASgGAHIAKAAIAAgqg");
	this.shape_54.setTransform(136.1,-163.2);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#333333").s().p("AAYCYQgRgHAEgRQAGgQASADIARAEQAfAHAHgBQAOAAAEgpQAFgmAAhyQgCgNgIAAIg5AAQgZA+gMAGQgLAHgKgJIAAB8QADAmgigCIhJAAQgnAEADgmIAAjEQgCgcAeABIARAAIABgIIAHgbQAGgRAUAAQASAEgCARQgBATgGAMIAYAAQAeAAgCAaIAAAmQATglAKgpIABgFQAFgaALgEQAbgEABAUQAAAMgEAOIA7AAQAngDgDAiIAAAiQAABygHAtQgEAqgSAJQgOAJgWAAQgbAAglgNgAhxBlQAAAHAHAAIAxAAQAGAAAAgHIAAhBIg+AAgAhxhDIAABDIA+AAIAAhBQAAgHgEAAIg0AAQgEAAgCAFgAA2BGQgJgVgWgtQgJgRAQgKQASgJALARQAYAkAIAgQAGAVgRAJQgFACgEAAQgLAAgGgPg");
	this.shape_55.setTransform(100.7,-163.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#333333").s().p("AhnCTQAAgUAUgBIAKgCQAngFASgEQgggWgOgTQgnA4gaAWQgSAPgOgNQgNgNAQgPQAwgsAdg+IgrAAQgTgDAEgUQgVACAAgbIAAgYQgBgbAfACIAiAAQgXgfANgGIgYAAQgRgBgBgSQACgRARgCIAYAAQCRACBcgMQAUgBACAUQgBASgUADIgDAAIgWABQANAGgHARQgCAAgLAVIAjAAQAcAAAAAVQAAAPgDANQgCAZgQAAQADATgUAEIijAAIgJAQICWAAQAnAFgRAfQgWAYgfATQAqAIAZADQAcAAgHAZQgBAQgmgHQg3gGgqgQQgvARg5AHIgEABQgSAAgEgQgAAeBgQAVgLAUgRIhVAAQAfAYANAEgAgYgRICTAAIAEgYIihAAQASADgIAVgAh2gSIA0AAQAGgWAGgBIhAAAgAAOh1QAQAmgKACIApAAQAPgbAGgPQgqACgaAAgAg+hNIA1AAQgPgjAIgDIghABIgYAAQAWAhgLAEg");
	this.shape_56.setTransform(64.4,-163.2);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#333333").s().p("AgBCTQgQgIAEgUQAHgRATADIAKACQAbAFAUAAQANACAAgQIAAjQIjnAAQgQgCAAgVQADgUAPgBIEiAAQATABACAUQgCAVgTACIgSAAIAADaQADAxg4gDIgLABQgfAAgggIgAiIAyIAAhoQADgZAbgCICLAAQAaAAAAAeIAABkQACAdgegBIiMAAIgCAAQgaAAABgbgAhfglIAABGQAAAGAGAAIBmAAQAFAAAAgGIAAhGQAAgGgFAAIhmAAQgGAAAAAGg");
	this.shape_57.setTransform(28.7,-162.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#333333").s().p("AgPCiQgQgNALgRIAEgEQAHgDADgFQgHgCgGgIQgIgNgIgVQgHgOANgIQASgGAHANIAQAdIAAADIACAHQAphCgBgzIAAggQABgOASgCQAUAAABAOIAAAjQAAAxAyBGIAFAIQAQARABAHQgDAfgdgIQgggegag+QgWA6glAgQgKAKgJAAQgGAAgHgEgAhpCfQgLgDAAgQQAFgTAKACQASAEgCgKIAAhFIg9AAQgPgBAAgTQABgSAQgBICOAAQAMABABASQAAATgLABIgtAAIAABUQAGAggiAAQgNAAgTgFgAifCEIACgIQAMglAEgTQAVgYAOAcQgFAigOAmQgLAGgHAAQgMAAgEgSgABpgCIADgMQANgtAAgSQgCgGgEgBIg7AAQgHAdgRAcQgQAbgVgSQAEAQgPACIh8AAQgVgRAWgPICCAAQAAgGAHgJQAOgSAQhKIABgHQAFgQAPAAQATADABAOQAAAKgDALIBHAAQAbgDgCAhQAAAagQBBIgCAJQgLAKgJAAQgLAAgIgSgAiGgsQgQgBgBgRQABgRAQgBIAtAAIAAgQIg9AAQgPgBAAgSQADgRAPgCIA6AAIAAgOQACgPAUgCQAUACACARIAAAMIArAAQAQACADARQAAASgRABIgtAAIAAAQIAcAAQAOABABARQgBARgOABg");
	this.shape_58.setTransform(-7.4,-163.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#333333").s().p("AiRAWQgQgBgCgVQACgUAQgCIEgAAQATACACAUQgCAVgTABg");
	this.shape_59.setTransform(-43.5,-163.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#333333").s().p("AigCAQABgCAGgDQAegdATg4QAGgQASADQASAEgCARQgCADAAAEIgHAUQAgAZAWAFIAAhVIh/AAQgSgCgCgQQAAgSATgBIEmAAQARABABARQgBARgRACIh8AAIAAAUIBnAAQAUACABAUQgDASgUACIhlAAIAAAeIB5AAQAVACACASQgCASgVACIhyAAQg9ADg7gsQgcAqgSAJIgIAAQgaAAAKgggAiHhAIAAg/QgEgjAiADIDGAAQAmgEgEAkIAAA/QAGAlgpgEIjCAAIgJABQgdAAAFgigAhfhCIC1AAIAAgNIi1AAgAhfhtIC1AAIAAgPIi1AAg");
	this.shape_60.setTransform(-79.5,-163);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#333333").s().p("AiiCeQgLgLALgOIAGgHQAgglAAgIIAAhQQAAgEgEAAIgRAAQgRgBAAgUQADgRARgBIAhAAQAbgBgBAcIAABgQAOAjBVAGICCAAQAUABADARQgBASgUACIh5AAQhAAAg1gdIgLgEQgGAAgUAVIgHAJQgHAGgIAAQgGAAgHgFgAhEBRQgEgSAXgJQAxgPAZgVQgMgJgXgMIgXgLQgTgLAKgSQALgOAWAIQAeAOAfAUQARgaAKgjIh/AAQgUgBgBgUQABgSAUgBIBLAAIgKgWQgEgOAPgIQAVgGAJANQAFAIAHARQAFAHABAFIBFAAQASABACASQgCAUgSABIgWAAQgKAvgYAlQAiAWAXAVQAQAQgLAPQgOAQgRgNIgOgKQghgbgKgFQgoAjg9APIgKABQgPAAgFgNgAhuhUQgLgQgZgWQgKgLAMgNQAMgKAOAKQASANAVAYQAIAMgMANQgIAFgHAAQgGAAgGgFg");
	this.shape_61.setTransform(-115.5,-164);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// 图层 1
	this.btn_confirm = new lib.确定();
	this.btn_confirm.parent = this;
	this.btn_confirm.setTransform(4.3,239.6,1,1,0,0,0,-1.3,-0.3);
	new cjs.ButtonHelper(this.btn_confirm, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.btn_confirm).wait(1));

	// 图层 4
	this.instance = new lib.帮助面板背景框();
	this.instance.parent = this;
	this.instance.setTransform(6.8,-44.4,1,1,0,0,0,0,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// 图层 3
	this.mc_bg = new lib.帮助面板背景();
	this.mc_bg.parent = this;
	this.mc_bg.setTransform(0,0,1.055,1.055);

	this.timeline.addTween(cjs.Tween.get(this.mc_bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.HelpPanel, new cjs.Rectangle(-675,-396.6,1350,793.1), null);


(lib.sprite14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape13("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite14, new cjs.Rectangle(1.9,5.8,357.1,245.2), null);


(lib.sprite12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.shape11("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite12, new cjs.Rectangle(-9,22.7,244.3,367.9), null);


(lib.元件4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Eg1JABvQguAAghggQgLgMgHgMQgOgZAAgeIAAAAIABgMIAAgDQAFgkAagbQALgKALgGQAZgQAgAAMBqTAAAQAeAAAYAOQANAHAMALQAHAIAGAJQAFAHAEAJQAKAVAAAYIAAAAQAAAPgDAOQgCAIgEAIIgBACQgFAKgGAJIgLANQghAgguAAg");
	mask.setTransform(351,0.3);

	// 图层 2
	this.instance = new lib.元件6_1();
	this.instance.parent = this;
	this.instance.setTransform(95.4,-1.3,1,0.396,0,-9,0,212.5,68.5);
	this.instance.filters = [new cjs.BlurFilter(3, 3, 1)];
	this.instance.cache(-2,-2,429,141);

	this.instance_1 = new lib.元件6_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(493.3,-1,1,0.396,0,-9,0,212.5,68.5);
	this.instance_1.filters = [new cjs.BlurFilter(3, 3, 1)];
	this.instance_1.cache(-2,-2,429,141);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// 图层 4
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FDE463","#FDE05C","#FDBD23","#FCB414"],[0,0.294,0.847,1],161.1,-7.1,161.1,2.9).s().p("EgiEAAwIAAhfMBEJAAAIAABfg");
	this.shape.setTransform(291.8,0.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FDE463","#FDE05C","#FDBD23","#FCB414"],[0,0.294,0.847,1],169.6,-7.1,169.6,2.9).s().p("AkeAwQgeAAgYgOIgHgFIgEgFQAIgWASgQQAKgKALgGQAZgQAhgBIJVAAIAABfg");
	this.shape_1.setTransform(38.5,0.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#FDE463","#FDE05C","#FDBD23","#FCB414"],[0,0.294,0.847,1],-112.2,-7.1,-112.2,2.9).s().p("Au5AwIAAhfIcyAAQAeABAYAOIAIAEIADAFIgCAFQgGALgHAJIgLANQghAhguAAg");
	this.shape_2.setTransform(605.3,0.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FE9C07").s().p("Eg1JABPQguAAghghQgLgLgHgNQgOgXAAgeIAAgBIABgNQAIARAOAPIAOALIADACIAIAFQAYAOAeAAIJ+AAMBEKAAAIcLAAQAuAAAhggIALgNQAHgKAFgKIADgGIADgLIACgPQAKAVAAAZIAAABQAAAPgDANQgCAIgEAIIgBACQgFAJgGAJIgLANQghAhguAAg");
	this.shape_3.setTransform(351,3.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEFA8B").s().p("Eg2PABFIgNgLQgPgPgIgRIAAgDQAFgjAbgbQAKgKALgGQAZgQAgAAMBqTAAAQAeAAAZAOQAMAHAMALQAHAIAGAJQAGAIAEAIIgDAOIgDALIgEgFIgHgEQgZgNgegBI8yAAMhEKAAAIpXAAQggABgZAPQgLAGgKAKQgSARgIAWIADAFIgDgDg");
	this.shape_4.setTransform(350.5,-3.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.元件4, new cjs.Rectangle(-0.3,-10.8,702.6,35.9), null);


(lib.光芒 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 20
	this.instance = new lib.sprite14();
	this.instance.parent = this;
	this.instance.setTransform(55.8,21.7,1,1.304,12.2);
	this.instance.alpha = 0.469;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,rotation:10.3,x:45.6,y:31,alpha:0.57},3).to({scaleX:1,rotation:3,x:8.6,y:68.8,alpha:1},10).to({rotation:12.2,x:55.8,y:21.7,alpha:0.469},15).wait(1));

	// Layer 17
	this.instance_1 = new lib.sprite12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(63.7,46.4,0.634,1,-31);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:0.63,scaleY:1,rotation:-29.8,x:69.7,y:41.9},3).to({scaleX:0.63,scaleY:1,rotation:-25.8,x:90.7,y:24.1},10).to({scaleX:0.63,scaleY:1,rotation:-26.8,x:85.5,y:28.7},3).to({scaleX:0.63,scaleY:1,rotation:-31,x:63.7,y:46.4},12).wait(1));

	// Layer 14
	this.instance_2 = new lib.sprite12();
	this.instance_2.parent = this;
	this.instance_2.setTransform(226.1,-31.7,0.369,1,-9.5);
	this.instance_2.alpha = 0.551;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:0.37,scaleY:1,rotation:-10.1,x:222.4,y:-30.4},3).to({rotation:-10.8,x:217.6,y:-28.8},3).to({rotation:-12.3,x:208.2,y:-25.7},4).to({scaleX:0.37,scaleY:1,rotation:-13.2,x:202.7,y:-24},3).to({scaleX:0.37,scaleY:1,rotation:-12.3,x:208.2,y:-25.7},3).to({rotation:-11.6,x:213,y:-27.3},3).to({rotation:-10.8,x:217.7,y:-28.8},3).to({scaleX:0.37,scaleY:1,rotation:-9.5,x:226.1,y:-31.7},6).wait(1));

	// Layer 11
	this.instance_3 = new lib.sprite12();
	this.instance_3.parent = this;
	this.instance_3.setTransform(219.5,-8.2,1,0.861);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleY:0.86,rotation:0.8,x:224,y:-9.7},3).to({rotation:4.5,x:245.5,y:-15.6},10).to({rotation:1.8,x:229.6,y:-11.3},9).to({rotation:0.8,x:224,y:-9.6},3).to({scaleY:0.86,rotation:0,x:219.5,y:-8.2},3).wait(1));

	// Layer 8
	this.instance_4 = new lib.sprite12();
	this.instance_4.parent = this;
	this.instance_4.setTransform(480.5,-45.8,0.634,1,31.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({scaleX:0.63,scaleY:1,rotation:30.8,x:475.2,y:-47.2},3).to({rotation:30.1,x:470.4,y:-48.9},3).to({scaleX:0.63,scaleY:1,rotation:28,x:456.7,y:-54},7).to({scaleX:0.63,scaleY:1,rotation:28.6,x:460.7,y:-52.2},3).to({scaleX:0.63,scaleY:1,rotation:31.6,x:480.5,y:-45.8},12).wait(1));

	// Layer 5
	this.instance_5 = new lib.sprite12();
	this.instance_5.parent = this;
	this.instance_5.setTransform(651.8,94.2,0.634,1,0,42.7,-137.3);
	this.instance_5.alpha = 0.469;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({scaleX:0.63,scaleY:1,skewX:43.4,skewY:-136.6,x:654,y:98.3,alpha:0.57},3).to({skewX:43.9,skewY:-136.1,x:656.2,y:101.1,alpha:0.68},3).to({scaleX:0.63,scaleY:1,skewX:45.9,skewY:-134.1,x:664.5,y:111.8,alpha:1},7).to({scaleX:0.63,scaleY:1,skewX:44.6,skewY:-135.4,x:659.1,y:105.1},6).to({skewX:43.9,skewY:-136.1,x:656.2,y:101.2},3).to({scaleX:0.63,scaleY:1,skewX:42.7,skewY:-137.3,x:651.8,y:94.2,alpha:0.469},6).wait(1));

	// Layer 2
	this.instance_6 = new lib.sprite12();
	this.instance_6.parent = this;
	this.instance_6.setTransform(709.2,220.3,0.436,1,0,66.3,-113.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({scaleY:1,skewX:65.4,skewY:-114.6,x:707.1,y:215,alpha:0.891},3).to({scaleY:1,skewX:61.9,skewY:-118.1,x:699.8,y:192.8,alpha:0.469},10).to({scaleY:1,skewX:62.9,skewY:-117.1,x:701.7,y:199.3,alpha:0.57},3).to({skewX:63.7,skewY:-116.3,x:703.5,y:204.2,alpha:0.68},3).to({scaleY:1,skewX:66.3,skewY:-113.7,x:709.2,y:220.3,alpha:1},9).wait(1));

	// Layer 1
	this.instance_7 = new lib.shape9("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(341,328.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(29));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.4,-29.5,701.5,648.9);


(lib.sprite42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		playSound("streamsound13");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(15));

	// Layer 6
	this.eye = new lib.sprite41();
	this.eye.parent = this;
	this.eye.setTransform(1.5,-0.3,0.563,0.563);

	this.timeline.addTween(cjs.Tween.get(this.eye).wait(1).to({y:4},1).to({y:26.4},2).to({y:32.1},1).wait(1).to({y:34},0).wait(2).to({y:29.7},1).to({y:16.9},1).to({y:-0.3},4).wait(1));

	// Layer 4
	this.instance = new lib.sprite31();
	this.instance.parent = this;
	this.instance.setTransform(-21.7,7.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,rotation:-7.5,y:11.5},1).to({scaleX:1,scaleY:1,rotation:-46.6,y:34},2).to({scaleX:1,scaleY:1,rotation:-60,y:41.6},2).to({scaleX:1,scaleY:1,rotation:-60.1,x:-21.6},1).to({scaleX:1,scaleY:1,rotation:-60,x:-21.7},1).to({scaleX:1,scaleY:1,rotation:-52.6,x:-21.6,y:37.3},1).to({scaleX:1,scaleY:1,rotation:-30,y:24.5},1).to({scaleX:1,scaleY:1,rotation:-18.8,x:-21.7,y:18},1).to({scaleX:1,scaleY:1,rotation:-1.8,y:8.3},2).wait(1).to({rotation:0,y:7.2},0).wait(2));

	// Layer 2
	this.instance_1 = new lib.sprite31();
	this.instance_1.parent = this;
	this.instance_1.setTransform(20.3,7.2,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1,scaleY:1,skewX:7.5,skewY:187.5,y:11.5},1).to({scaleX:1,scaleY:1,skewX:46.6,skewY:226.6,y:34},2).to({scaleX:1,scaleY:1,skewX:60,skewY:240,y:41.6},2).to({scaleX:1,scaleY:1,skewX:60.1,skewY:240.1},1).to({scaleX:1,scaleY:1,skewX:60,skewY:240},1).to({scaleX:1,scaleY:1,skewX:52.6,skewY:232.6,y:37.4},1).to({scaleX:1,scaleY:1,skewX:30,skewY:210,y:24.5},1).to({scaleX:1,scaleY:1,skewX:18.8,skewY:198.8,y:18},1).to({scaleX:1,scaleY:1,skewX:1.8,skewY:181.8,x:20.2,y:8.3},2).wait(1).to({skewX:0,skewY:180,x:20.3,y:7.2},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.8,-44.5,222.2,73);


(lib.元件5复制 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.sprite42();
	this.instance.parent = this;
	this.instance.setTransform(5.8,110.6,0.604,0.604,-15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.元件5复制, new cjs.Rectangle(-66.5,67.3,137.4,64.2), null);


(lib.元件1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// shape 869
	this.mc_star = new lib.shape869();
	this.mc_star.parent = this;
	this.mc_star.setTransform(0,0,1.2,1.2);

	this.timeline.addTween(cjs.Tween.get(this.mc_star).wait(1));

	// 图层 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EAAAAkPQgJgBgJgCQgGgBgFgDIgNgIIgJgHQgVgWAAgeMAAAhGJQAAgfAVgVQAIgIAIgEQAQgJATAAIAAAAIAJAAIACAAQAYADARASQAHAHAEAGQAKASAAAVMAAABGJQAAAUgJAQQgEAIgIAIQgKAKgLAFQgOAGgRABg");
	mask.setTransform(0.2,234.6);

	// 元件 4
	this.mc_bar = new lib.元件4();
	this.mc_bar.parent = this;
	this.mc_bar.setTransform(-7.9,141.3,0.66,0.66,90,0,0,209.5,12.5);

	var maskedShapeInstanceList = [this.mc_bar];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.mc_bar).wait(1));

	// 元件 7
	this.mc_bg = new lib.元件7_1();
	this.mc_bg.parent = this;
	this.mc_bg.setTransform(0.1,328.6,0.66,0.66,90,0,0,213,14.7);
	this.mc_bg.filters = [new cjs.ColorMatrixFilter(new cjs.ColorMatrix(-28, 0, -18, 0))];
	this.mc_bg.cache(-287,-2,715,34);

	this.timeline.addTween(cjs.Tween.get(this.mc_bg).wait(1));

	// 主画面-腾满 副本 3
	this.instance = new lib.主画面腾满副本3();
	this.instance.parent = this;
	this.instance.setTransform(150.4,83,0.582,0.582,0,90,-90,299.2,99);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.498)",0,5,5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.元件1, new cjs.Rectangle(-20.7,-28.1,55.4,518), null);


(lib.GameScene = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//引用第三方方法
		function RanomArray3(arr)
		{
			var outputArr = arr.slice();
			var i = outputArr.length;
			var temp;
			var indexA;
			var indexB;
		
			while (i)
			{
				indexA = i - 1;
				indexB = Math.floor(Math.random() * i);
				i--;
		
				if (indexA == indexB)
				{
					continue;
				}
		
				temp = outputArr[indexA];
				outputArr[indexA] = outputArr[indexB];
				outputArr[indexB] = temp;
			}
		
			return outputArr;
		}
		//测试关卡
		var m_level_test = 
		{
			row: 1,
			column: 2,
			random: true,
			count: 1,
			showtime:2000,
			countdown:10,
			dictionary: []
		}
		
		//关卡
		var m_level_1 = {
			row: 2,
			column: 3,
			random: true,
			count: 3,
			showtime:1000,
			countdown:20,
			dictionary: []
		};
		var m_level_2 = {
			row: 2,
			column: 4,
			random: true,
			count: 4,
			showtime:2000,
			countdown:30,
			dictionary: []
		};
		var m_level_3 = {
			row: 2,
			column: 5,
			random: true,
			count: 5,
			showtime:3000,
			countdown:40,
			dictionary: []
		};
		var m_level_4 = {
			row: 3,
			column: 4,
			random: true,
			count: 6,
			showtime:4000,
			countdown:50,
			dictionary: []
		};
		var m_level_5 = {
			row: 2,
			column: 7,
			random: true,
			count: 7,
			showtime:5000,
			countdown:60,
			dictionary: []
		};
		var m_level_6 = {
			row: 2,
			column: 8,
			random: true,
			count: 8,
			showtime:5000,
			countdown:70,
			dictionary: []
		};
		var m_level_7 = {
			row: 3,
			column: 6,
			random: true,
			count: 9,
			showtime:6000,
			countdown:80,
			dictionary: []
		};
		var m_level_8 = {
			row: 3,
			column: 7,
			random: true,
			count: 10,
			showtime:6000,
			countdown:90,
			dictionary: []
		};
		var m_level_9 = {
			row: 3,
			column: 8,
			random: true,
			count: 11,
			showtime:7000,
			countdown:100,
			dictionary: []
		};
		var m_level_10 = {
			row: 3,
			column: 8,
			random: true,
			count: 12,
			showtime:8000,
			countdown:120,
			dictionary: []
		};
		//窗体文档
		var m_world = this;
		var m_arrLevels = [m_level_1, m_level_2, m_level_3, m_level_4, m_level_5, m_level_6, m_level_7, m_level_8, m_level_9, m_level_10];
		//var m_arrLevels = [m_level_test,m_level_test,m_level_test,m_level_test,m_level_test,m_level_test,m_level_test,m_level_test,m_level_test,m_level_test];
		
		var m_nCurrentLevelIndex = 0;//当前关卡索引
		var m_objCurrentLevel = m_arrLevels[m_nCurrentLevelIndex];//当前关卡
		//
		var MAX_SIZE = 12;//最大卡牌个数
		var HanZiStartFrameIndex = 0;//汉字起始索引值
		var PinYinStartFrameIndex = 50;//拼音起始索引值
		var BACK = "back";//背面
		
		var m_fCardWidth = 100;//卡牌宽
		var m_fCardHeight = 100;//卡牌高
		var m_fInitX = 0;//卡牌阵列左上角X值
		var m_fInitY = 0;//卡牌阵列左上角Y值
		var m_fHGap = -5;//卡片阵列水平间距
		var m_fVGap = -5;//卡片阵列竖直间距
		var m_fMovieWidth = 0;//卡牌阵列宽度
		var m_fMovieHeight = 0;//卡牌阵列高度
		var m_nTimer = 0;//计时器
		var m_nTimerCount = 0;//计时个数
		var m_bOpenFirst = true;//如果为true, 先展示卡牌内容, 之后翻转到背面; 如果为false,直接是卡牌背面.
		
		var m_arrCompareList = [];//比对列表. 当有两个值时就开始比对
		var m_arrCardList = [];//卡牌列表
		
		//游戏初始化
		function gameInit()
		{
			initData();
			initView();
		}
		
		//数据初始化
		function initData()
		{
			var card = new lib.Card();
		
			m_fCardWidth = card.nominalBounds.width;
			m_fCardHeight = card.nominalBounds.height;
		
			card = null;
			
			createjs.EventDispatcher.initialize(m_world);
		}
		//初始化视图
		function initView()
		{
			drawListByLevel(m_objCurrentLevel);
			
			var e = new createjs.Event(GameEvent.INIT);
			//e.target = {width:width, height:height};
			e.movieWidth = m_fMovieWidth;
			e.movieHeight = m_fMovieHeight;
			m_world.dispatchEvent(e, m_world);
			
			showLevel(1);
			
			var showtime = (m_bOpenFirst ? m_objCurrentLevel.showtime : 0);
			
			setTimeout(function(){showLabel(new lib.LabelThree())}, showtime + 1000);
			setTimeout(function(){showLabel(new lib.LabelTwo())}, showtime + 2000);
			setTimeout(function(){showLabel(new lib.LabelOne())}, showtime + 3000);
			setTimeout(function(){showLabel(new lib.LabelGo())}, showtime + 4000);
			
			setTimeout(gameStart, showtime + 5000);
			
			if (m_bOpenFirst)
			{//倒数结束前翻转所有牌
				setTimeout(flipAllCards, showtime + 4000);
			}
		}
		
		//游戏开始
		function gameStart()
		{
			var len = m_arrCardList.length;
			
			for (var i=0;i<len;i++)
			{
				m_arrCardList[i].mouseEnabled = true;
			}
			
			startTimer();
		}
		
		//生成图形矩阵
		function drawListByLevel(level)
		{
			var row = level.row;
			var column = level.column;
			var dict = getOriginalDictionary(level);
			var ziList = getHanZiList(dict);
			var pinyinList = getPinyinList(dict);
			var card;
			
			dict = ziList.concat(pinyinList.slice());
		
			var levelCardData = RanomArray3(dict);
			//alert(levelCardData);
			m_fMovieWidth = (m_fCardWidth + m_fHGap) * column - m_fHGap;
			m_fMovieHeight = (m_fCardHeight + m_fVGap) * row - m_fVGap;
			m_fInitX = m_fCardWidth * 0.5 + GameGlobalData.STAGE_WIDTH * 0.5 - m_fMovieWidth * 0.5;
			m_fInitY = m_fCardHeight * 0.5 + GameGlobalData.STAGE_HEIGHT * 0.5 - m_fMovieHeight * 0.5 + 50;
			
			for (var i = 0; i < row; i++) //row
			{
				for (var j = 0; j < column; j++) //column
				{
					if (levelCardData.length > 0)
					{
						card = createCard();
		
						if (card != null)
						{
							m_world.addChild(card);
							m_arrCardList.push(card);
		
							if (i == 0 && j == 0)
							{
								//alert(card.nominalBounds.width);
							}
		
							card.x = m_fInitX + j * (m_fCardWidth + m_fHGap);
							card.y = m_fInitY + i * (m_fCardHeight + m_fVGap);
		
							card.data = levelCardData.pop();
							
							if (m_bOpenFirst)
							{
								card.gotoAndStop(card.data.frame);
								card.mc_bg.gotoAndStop("close");
							}
							else
							{
								card.gotoAndStop(BACK);
							}
							
							card.mouseEnabled = false;
							card.addEventListener("mousedown", onCardBackMouseDown);
							
							card.scaleX = card.scaleY = 0.85;
							card.alpha = 0;
							createjs.Tween.get(card)
										  .wait(1000 + i * 200 + j * 50)
										  .to({scaleX:1, scaleY:1, alpha:1}, 300);
						}
					}
				}
			}
		}
		
		//根据关卡信息, 随机获取字库中的字
		function getOriginalDictionary(level)
		{
			if (level.random)
			{
				var re = [];
		
				for (var i = 1; i <= MAX_SIZE; i++)
				{
					re.push(i);
				}
		
				re = RanomArray3(re);
		
				return re.slice(0, level.count);
			}
			else
			{
				return level.dictionary.slice();
			}
		}
		
		//汉字列表
		function getHanZiList(list)
		{
			var re = [];
			var len = list.length;
		
			for (var i = 0; i < len; i++)
			{
				re.push(
				{
					id: list[i],
					frame: list[i] + HanZiStartFrameIndex,
					removed:false
				});
			}
		
			return re;
		}
		
		//拼音列表
		function getPinyinList(list)
		{
			var re = [];
			var len = list.length;
		
			for (var i = 0; i < len; i++)
			{
				re.push(
				{
					id: list[i],
					frame: list[i] + PinYinStartFrameIndex,
					removed:false
				});
			}
		
			return re;
		}
		
		//点击事件处理
		function onCardBackMouseDown(e)
		{
			if (m_arrCompareList.length >= 2)
			{
				return;
			}
			
			var isSecondCard = false;
			
			if (m_arrCompareList.length == 1)
			{
				isSecondCard = true;
			}
			
			var card = e.currentTarget;
				//alert(card.mc_bg.currentLabel);
			if (m_arrCompareList.indexOf(card) != -1 || (card.mc_bg.currentLabel != "open" && card.mc_bg.currentLabel != "close"))
			{//已经存在于比对列表中
				return;
			}
			
			m_arrCompareList.push(card); //将背面图标压入比对列表m_vecCompareList中
			
			card.mc_bg.gotoAndStop("open");
			card.mc_bg.play();
			
			var tween = createjs.Tween.get(card, {loop: false})
									  .wait(200)
									  .call(gotoandstop)
									  .wait(200)
									  .call(tweenComplete);
			
			
			/*var tween = createjs.Tween.get(card, {loop: false})
							.to({scaleX: 0.95, scaleY: 0.95, alpha: 0}, 200, createjs.Ease.backIn)
							.call(gotoandstop)
							.to({scaleX: 1.25, scaleY: 1.25, alpha:1}, 350, createjs.Ease.backIn)
							.to({scaleX: 1, scaleY: 1}, 350, createjs.Ease.backOut)
							.wait(500)
							.call(tweenComplete);*/
							
				function tweenComplete(tween) {
					if (isSecondCard)
					{
						startCompare(); //配对比较
					}
				}
				
				function gotoandstop(tween)
				{
					e.currentTarget.gotoAndStop(e.currentTarget.data.frame);
				}
		}
		
		//创建卡牌
		function createCard()
		{
			return new lib.Card();
		}
		
		//开始比对处理
		function startCompare()
		{
			if (m_arrCompareList.length == 2)
			{ //如果比对数组达到2个，开始比对
		
				if (compared(m_arrCompareList))
				{ //如果比对成功，消除
					gotoDisVisible(m_arrCompareList);
		
					if (finished())
					{ //如果完成
						clearInterval(m_nTimer);
						
						if (m_nCurrentLevelIndex == m_arrLevels.length - 1)
						{//通关
							setTimeout(showFinishedPanel, 1000);
						}
						else
						{//下一关
							setTimeout(showNextLevel, 1000);
						}
					}
				}
				else
				{ //如果比对失败，恢复背面
					gotoBack(m_arrCompareList);
				}
				
				clearCompareList(m_arrCompareList);
			}
		}
		
		//比对
		function compared(list)
		{
			if (list && list.length < 2)
			{
				return false;
			}
		
			return list[0].data.id == list[1].data.id;
		}
		
		//设置不可见
		function gotoDisVisible(list)
		{ //增加消失特效
			
			var card1 = list[0];
			var card2 = list[1];
			
			card1.data.removed = true;
			card2.data.removed = true;
			
			createjs.Tween.get(card1, {loop: false})
							.to({scaleX: 0.75, scaleY: 0.75, alpha: 0}, 350, createjs.Ease.backIn)
							.call(function(){explosion(10, card1.x, card1.y, 300, 500, 180);});
							
			createjs.Tween.get(card2, {loop: false})
							.to({scaleX: 0.75, scaleY: 0.75, alpha: 0}, 350, createjs.Ease.backIn)
							.call(function(){explosion(10, card2.x, card2.y, 300, 500, 180);});
		}
		
		//返回背面
		function gotoBack(list)
		{ //增加特效
			
			var card1 = list[0];
			var card2 = list[1];
			
			var tween = createjs.Tween.get(card1, {loop: false})
									  .call(card1.gotoAndStop, [BACK])
									  .call(function(){card1.mc_bg.gotoAndStop('close');card1.mc_bg.play();});
		
			var tween = createjs.Tween.get(card2, {loop: false})
									  .call(card2.gotoAndStop, [BACK])
									  .call(function(){card2.mc_bg.gotoAndStop('close');card2.mc_bg.play();});
			
			/*
			createjs.Tween.get(list[0], {loop: false})
							.to({scaleX: 0.95, scaleY: 0.95, alpha: 0}, 100, createjs.Ease.backIn)
							.call(list[0].gotoAndStop, [BACK])
							.to({scaleX: 1.25, scaleY: 1.25, alpha:1}, 350, createjs.Ease.backIn)
							.to({scaleX: 1, scaleY: 1}, 350, createjs.Ease.backOut);
							
			createjs.Tween.get(list[1], {loop: false})
							.to({scaleX: 0.95, scaleY: 0.95, alpha: 0}, 100, createjs.Ease.backIn)
							.call(list[1].gotoAndStop, [BACK])
							.to({scaleX: 1.25, scaleY: 1.25, alpha:1}, 350, createjs.Ease.backIn)
							.to({scaleX: 1, scaleY: 1}, 350, createjs.Ease.backOut);
			*/
		}
		
		//清除比对数组
		function clearCompareList(list)
		{
			if (list)
			{
				while (list.length > 0)
				{
					list.pop();
				}
			}
		}
		
		//翻转所有的牌
		function flipAllCards()
		{
			var len = m_arrCardList.length;
		
			for (var z = 0; z < len; z++)
			{
				m_arrCardList[z].gotoAndStop(BACK);
				m_arrCardList[z].mc_bg.gotoAndStop("close");
				m_arrCardList[z].mc_bg.play();
			}
		}
		
		//清除卡牌数组
		function clearAllCards()
		{
			while(m_arrCardList.length > 0)
			{
				var card = m_arrCardList.pop();
				if (card)
				{
					if (m_world.contains(card))
					{
						m_world.removeChild(card);
					}
					
					card = null;
				}
			}
		}
		
		//检测是否完成
		function finished()
		{
			var len = m_arrCardList.length;
		
			for (var i = 0; i < len; i++)
			{
				if (!m_arrCardList[i].data.removed)
				{
					return false;
				}
			}
		
			return true;
		}
		
		//展示下一关内容
		function showNextLevel()
		{
			//清除所有卡牌
			clearCompareList(m_arrCompareList);
			clearAllCards();
			//更新关卡索引
			m_nCurrentLevelIndex ++;
			//更新关卡数据
			if (m_nCurrentLevelIndex < m_arrLevels.length)
			{
				m_objCurrentLevel = m_arrLevels[m_nCurrentLevelIndex];
			}
			//建立卡牌矩阵
			drawListByLevel(m_objCurrentLevel);
			
			//
			restartCountdown();
			//
			showLevel(m_nCurrentLevelIndex);
			//
			var showtime = (m_bOpenFirst ? m_objCurrentLevel.showtime : 0);
			
			setTimeout(function(){showLabel(new lib.LabelThree())}, showtime + 1000);
			setTimeout(function(){showLabel(new lib.LabelTwo())}, showtime + 2000);
			setTimeout(function(){showLabel(new lib.LabelOne())}, showtime + 3000);
			setTimeout(function(){showLabel(new lib.LabelGo())}, showtime + 4000);
			
			setTimeout(gameStart, showtime + 5000);
			
			if (m_bOpenFirst)
			{//倒数结束前翻转所有牌
				setTimeout(flipAllCards, showtime + 4000);
			}
		}
		
		//展示完成面板
		function showFinishedPanel()
		{
			var successPanel = new lib.SuccessPanel();
			m_world.addChild(successPanel);
			
			successPanel.x = GameGlobalData.STAGE_WIDTH * 0.5;
			successPanel.y = GameGlobalData.STAGE_HEIGHT * 0.5;
			
			successPanel.scaleX = 1.5;
			successPanel.scaleY = 1.5;
			successPanel.alpha = 0;
			
			var tween = createjs.Tween.get(successPanel)
									  .to({scaleX:1, scaleY:1, alpha:1}, 750, createjs.Ease.backInOut);
									  
			//successPanel.addEventListener("close", onSuccessPanelClose, false);
		}
		
		//关闭失败面板
		function showFailedPanel()
		{
			var failPanel = new lib.FailPanel();
			m_world.addChild(failPanel);
			
			failPanel.x = GameGlobalData.STAGE_WIDTH * 0.5;
			failPanel.y = GameGlobalData.STAGE_HEIGHT * 0.5;
			
			failPanel.scaleX = 1.5;
			failPanel.scaleY = 1.5;
			failPanel.alpha = 0;
			
			var tween = createjs.Tween.get(failPanel)
									  .to({scaleX:1, scaleY:1, alpha:1}, 750, createjs.Ease.backInOut);
		}
		
		//function onSuccessPanelClose(e)
		//{
			//m_world.removeChild(e.target);
			//e.target = null;
		//}
		
		//开始计时
		function startTimer()
		{
			restartCountdown();
			
			m_nTimer = setInterval(onTimerUpdate, 1000);
		}
		//重启计器
		function restartCountdown()
		{
			clearInterval(m_nTimer);
			m_nTimerCount = 0;
			
			createjs.Tween.get(m_world.mc_countdown.mc_bar, {loop: false})
							.to({y:141.3}, 200);
			createjs.Tween.get(m_world.mc_countdown.mc_star, {loop: false})
							.to({y:0}, 200);
		}
		
		//计时器更新事件
		function onTimerUpdate()
		{
			m_nTimerCount++;
			
			//console.log(m_nTimerCount, m_objCurrentLevel.countdown);
			
			var h = 465;
			var speed = h / m_objCurrentLevel.countdown;
			
			//m_world.mc_countdown.mc_bar.y += 10;
			//m_world.mc_countdown.mc_star.y += 10;
			
			if (m_nTimerCount >= m_objCurrentLevel.countdown + 1)
			{
				checkTimeout();
			}
			else
			{
				createjs.Tween.get(m_world.mc_countdown.mc_bar)
						  .to({y:m_world.mc_countdown.mc_bar.y + speed}, 1000, createjs.Ease.linear);
						  
				createjs.Tween.get(m_world.mc_countdown.mc_star)
						  .to({y:m_world.mc_countdown.mc_star.y + speed}, 1000, createjs.Ease.linear);
			}
		}
		
		//检测是否超时
		function checkTimeout()
		{
			clearInterval(m_nTimer);
			//结束，失败
			showFailedPanel();
		}
		
		//显示信息
		function showLabel(label)
		{
			if (label)
			{
				m_world.addChild(label);
				
				label.x = GameGlobalData.STAGE_WIDTH * 0.5;
				label.y = GameGlobalData.STAGE_HEIGHT * 0.5 + 55;
				label.scaleX = 2;
				label.scaleY = 2;
				label.alpha = 0;
				
				createjs.Tween.get(label)
							  .to({scaleX:1, scaleY:1, alpha:1}, 500, createjs.Ease.backInOut)
							  .wait(350)
							  .to({scaleX:0, scaleY:0, alpha:0}, 500, createjs.Ease.backInOut)
							  .call(function(){m_world.removeChild(label); label = null;});
			}
		}
		
		//显示关卡数
		function showLevel(frameIndex)
		{
			if (frameIndex > -1 && frameIndex < m_world.mc_level.totalFrames)
			{
				m_world.mc_level.alpha = 0;
				m_world.mc_level.y = 90 - 50;
				m_world.mc_level.gotoAndStop(frameIndex);
				
				createjs.Tween.get(m_world.mc_level)
							  .to({y:90, alpha:1}, 500, createjs.Ease.backInOut);
			}
		}
		
		//爆炸效果
		function explosion(num, xpos, ypos, round, time, angle)
		{
			for (var i = 0; i < num; i++)
			{
				var star = new lib.StarParticle();
				star.x = xpos;
				star.y = ypos;
				star.scaleX = star.scaleY = Math.random() * 0.5 + 0.5;
				star.alpha = Math.random();
				m_world.addChild(star);
				
				//var filter = new createjs.ColorFilter(1,0,0,1); //green&blue = 0, only red and alpha stay
				//star.filters = [filter];
				
				var targetX = xpos + Math.random() * round-round * 0.5;
				var targetY = ypos + Math.random() * round-round * 0.5;
				
				createjs.Tween.get(star)
							  .to({x:targetX, y:targetY, alpha:0, rotation:Math.random() * angle}, time, createjs.Ease.quadOut)
							  .call(function(){m_world.removeChild(star); star = null;});
			}
		}
		
		//清理当前关卡
		function clearLevel()
		{
			
		}
		
		//调用游戏窗口入口程序
		gameInit();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 5
	this.instance = new lib.dongshilogo();
	this.instance.parent = this;
	this.instance.setTransform(16,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// 图层 3
	this.mc_level = new lib.mc_level();
	this.mc_level.parent = this;
	this.mc_level.setTransform(641.3,90.3);

	this.timeline.addTween(cjs.Tween.get(this.mc_level).wait(1));

	// 图层 4
	this.mc_countdown = new lib.元件1();
	this.mc_countdown.parent = this;
	this.mc_countdown.setTransform(42.1,382.7,1,1,0,0,0,1.1,197.2);

	this.timeline.addTween(cjs.Tween.get(this.mc_countdown).wait(1));

	// 图层 2
	this.instance_1 = new lib.Bitmap7();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1178,329,1.222,1.697);

	this.instance_2 = new lib.Bitmap7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1180,593);

	this.instance_3 = new lib.Bitmap7();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1116,130);

	this.instance_4 = new lib.Bitmap9();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1088,678);

	this.instance_5 = new lib.Bitmap5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(1134,397);

	this.instance_6 = new lib.游戏背景();
	this.instance_6.parent = this;
	this.instance_6.setTransform(640,376,1,1,0,0,0,640,376);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.GameScene, new cjs.Rectangle(0,0,1299,752), null);


(lib.FailPanel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var m_world = this;
		
		this.btn_home.addEventListener("mousedown", onHomeClick);
		this.btn_replay.addEventListener("mousedown", onReplayClick);
		
		this.mc_bg.addEventListener("click", function(e){});
		
		function onHomeClick(e)
		{
			var evt = new createjs.Event(GameEvent.SWITCH_SCENE, true);
			evt.sceneType = GameGlobalData.SCENE_HOME;
			m_world.dispatchEvent(evt, m_world);
		}
		
		function onReplayClick(e)
		{
			var evt = new createjs.Event(GameEvent.SWITCH_SCENE, true);
			evt.sceneType = GameGlobalData.SCENE_GAME;
			m_world.dispatchEvent(evt, m_world);
		}
		
		m_world.mc_spider.rotation = 15;
		
		createjs.Tween.get(m_world.mc_spider, {loop: true})
							.to({rotation:-15}, 2000, createjs.Ease.quadInOut)
							.to({rotation:15}, 2000, createjs.Ease.quadInOut);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.btn_replay = new lib.失败重试();
	this.btn_replay.parent = this;
	this.btn_replay.setTransform(76,187);
	this.btn_replay.visible = false;
	new cjs.ButtonHelper(this.btn_replay, 0, 1, 1);

	this.btn_home = new lib.失败返回();
	this.btn_home.parent = this;
	this.btn_home.setTransform(21,187);
	new cjs.ButtonHelper(this.btn_home, 0, 1, 1);

	this.instance = new lib.元件5复制();
	this.instance.parent = this;
	this.instance.setTransform(-10.3,155.7,1,1,0,0,0,211.2,83.3);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,19);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.btn_home},{t:this.btn_replay}]}).wait(1));

	// 图层 3
	this.instance_1 = new lib.Bitmap13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-338,-214);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// 图层 4
	this.mc_spider = new lib.元件5();
	this.mc_spider.parent = this;
	this.mc_spider.setTransform(217.1,32.5,1,1,0,0,0,1.2,-1.8);
	this.mc_spider.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,19);

	this.timeline.addTween(cjs.Tween.get(this.mc_spider).wait(1));

	// 图层 5
	this.mc_bg = new lib.帮助面板背景();
	this.mc_bg.parent = this;
	this.mc_bg.setTransform(0,0,1.055,1.055);

	this.timeline.addTween(cjs.Tween.get(this.mc_bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.FailPanel, new cjs.Rectangle(-675,-396.5,1350,793.1), null);


(lib.SuccessPanel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var m_world = this;
		
		this.btn_home.addEventListener("mousedown", onHomeClick);
		this.btn_replay.addEventListener("mousedown", onReplayClick);
		
		this.mc_bg.addEventListener("click", function(e){});
		
		function onHomeClick(e)
		{
			var evt = new createjs.Event(GameEvent.SWITCH_SCENE, true);
			evt.sceneType = GameGlobalData.SCENE_HOME;
			m_world.dispatchEvent(evt, m_world);
		}
		
		function onReplayClick(e)
		{
			var evt = new createjs.Event(GameEvent.SWITCH_SCENE, true);
			evt.sceneType = GameGlobalData.SCENE_GAME;
			m_world.dispatchEvent(evt, m_world);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 6
	this.btn_home = new lib.btn_home();
	this.btn_home.parent = this;
	this.btn_home.setTransform(27,187);
	new cjs.ButtonHelper(this.btn_home, 0, 1, 1);

	this.btn_replay = new lib.btn_replay();
	this.btn_replay.parent = this;
	this.btn_replay.setTransform(66,187);
	this.btn_replay.visible = false;
	new cjs.ButtonHelper(this.btn_replay, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn_replay},{t:this.btn_home}]}).wait(1));

	// 图层 5
	this.instance = new lib.Bitmap1_1();
	this.instance.parent = this;
	this.instance.setTransform(-437,-202);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// 图层 4
	this.instance_1 = new lib.光芒();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-356.2,-377.4,1.114,1.114);
	this.instance_1.alpha = 0.469;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// 图层 3
	this.mc_bg = new lib.帮助面板背景();
	this.mc_bg.parent = this;
	this.mc_bg.setTransform(0,0,1.055,1.055);

	this.timeline.addTween(cjs.Tween.get(this.mc_bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.SuccessPanel, new cjs.Rectangle(-675,-410.3,1350,806.9), null);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		createjs.Touch.enable(this.getStage());
		
		var Scenes = [GameGlobalData.SCENE_HOME, GameGlobalData.SCENE_GAME];
		
		//窗体文档
		var m_world = this;
		var m_currentScene;
		var m_gameScene;
		
		//游戏初始化
		function gameInit()
		{
			initData();
			initEvent();
			initView();
		}
		
		function initEvent()
		{
			m_world.addEventListener(GameEvent.SWITCH_SCENE, onSwitchScene);
		}
		
		//数据初始化
		function initData()
		{
			
		}
		
		//function onGameInit(e)
		//{
			//if (m_currentScene)
			//{
				//m_currentScene.x = GameGlobalData.STAGE_WIDTH * 0.5 - e.movieWidth * 0.5;
				//m_currentScene.y = GameGlobalData.STAGE_HEIGHT * 0.5 - e.movieHeight * 0.5;
			//}
		//}
		
		function initView()
		{
			createScene(GameGlobalData.SCENE_HOME);
		}
		
		function onSwitchScene(e)
		{
			if (Scenes.indexOf(e.sceneType) == -1)
			{
				alert(GameGlobalData.ERR_INFO_SCEN_NOT_EXIST);
				return;
			}
			else
			{
				if (m_currentScene)
				{
					m_world.removeChild(m_currentScene);
					//m_currentScene.removeEventListener(GameEvent.INIT, onGameInit);
					m_currentScene = null;
				}
			}
			
			createScene(e.sceneType);
		}
		
		function createScene(sceneType)
		{
			switch (sceneType) 
			{
				case GameGlobalData.SCENE_HOME:
					m_currentScene = new lib.HomeScene();
					break;
				case GameGlobalData.SCENE_GAME:
					m_currentScene = new lib.GameScene();
					//m_currentScene.addEventListener(GameEvent.INIT, onGameInit, false);
					break;
				default:
					break;
			}
			
			if (m_currentScene)
			{
				m_world.addChild(m_currentScene);
			}
		}
		
		gameInit();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 全局背景
	this.instance = new lib.全局背景();
	this.instance.parent = this;
	this.instance.setTransform(640,376,1,1,0,0,0,640,376);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(639.5,375.5,1281,753);
// library properties:
lib.properties = {
	width: 1280,
	height: 752,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_.png?1484903095227", id:"index_atlas_"},
		{src:"sounds/streamsound13.mp3?1484903095374", id:"streamsound13"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;